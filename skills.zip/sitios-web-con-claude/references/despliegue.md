# Despliegue: el flujo de Hostinger

Un solo comando lleva la carpeta al sitio publicado. El orden importa porque las etiquetas Open Graph necesitan la URL definitiva antes de crear el archivo ZIP.

## La explicación honesta de costos (darla durante la configuración y repetirla antes de gastar; el punto sobre hosting espera hasta la Fase 10)

Siempre se habla de dinero ANTES de gastar:

- Una imagen principal cuesta alrededor de 2 créditos con la configuración recomendada.
- Un video principal cuesta aproximadamente entre 10 y 55 créditos, según el modelo elegido. Haz una consulta previa para obtener el precio exacto. El conector ofrece varios modelos de video y, al momento de escribir esto, tanto los más económicos como los más caros ofrecen calidad de primer nivel. La elección y la forma de explicarla con honestidad están en la sección de consulta previa de costos de `leyes-de-prompts.md`.
- El precio exacto de cada generación se puede consultar GRATIS antes de gastar con `get_cost: true`. Consulta todo: tomas individuales, imágenes de apoyo y cadenas completas. La comparación de modelos está en la sección de consulta previa de costos de `leyes-de-prompts.md`. Presenta el total con palabras sencillas antes de generar.
- Empieza con la prueba gratuita de Higgsfield. Alcanza para crear un primer sitio de recorrido único, incluido un intento adicional, y ya se han completado proyectos reales usando solo los créditos de prueba. Un modelo de video más económico puede extender todavía más esos créditos, desde una toma hasta varias. Sube a un plan de pago cuando vayas a crear más sitios o un proyecto más grande, y revisa los planes vigentes en `https://createaprowebsite.com/higgsfield` en vez de confiar en una cifra escrita aquí. Explícalo con claridad para que el usuario pueda planear.
- El hosting se paga por separado, y este punto debe esperar. Solo se menciona en la Fase 10, cuando el usuario diga que quiere publicar el sitio, nunca durante la configuración inicial. Cualquier plan de Hostinger con hPanel puede servir un sitio estático. La opción más económica suele estar entre los planes de hosting web compartido, normalmente con un precio promocional mensual y otro mayor al renovar. Revisa el precio vigente en `https://createaprowebsite.com/hosting170` en vez de confiar en una cifra escrita aquí. Publicar y volver a publicar no tiene costo adicional.

## Paso 0: conectar el hosting (solo en el primer despliegue)

El conector se agrega ahora, no durante la configuración inicial, porque antes de este momento no se necesita. Si las herramientas de hosting ya responden porque se conectaron en un proyecto anterior o antes en este mismo proyecto, ve directamente al Paso 1.

1. El usuario necesita un plan de hosting. Este es el momento de explicar el punto sobre hosting de la conversación de costos, si todavía no se ha mencionado. Si necesita contratarlo, comparte el enlace de afiliado `https://createaprowebsite.com/hosting170` y aclara que es de afiliado. Si ya cuenta con un plan de Hostinger, no hace falta enviarle el enlace de contratación. Cuando el plan esté listo, normalmente copiará el comando del conector desde la página de conectores de Hostinger. El botón Install Extension, con Claude Code seleccionado, muestra el comando. Si solo dice que el hosting está listo, ejecútalo tú: en Windows, `claude mcp add hostinger -- npx.cmd -y hostinger-api-mcp`; en Mac o Linux, el mismo comando con `npx`. La página de Hostinger muestra `npx` para todas las plataformas. Interpreta un comando pegado como la intención del usuario y adáptalo al equipo actual. En Windows usa `npx.cmd`. No hace falta explicar la diferencia.
2. Inmediatamente después de ejecutarlo, activa el inicio de sesión mediante una consulta de lectura inofensiva, como listar sus sitios web. En la mayoría de los equipos, el navegador abre Hostinger en unos instantes. El usuario inicia sesión, pulsa Allow y autoriza una sola vez. Avísale que la página puede abrirse en un navegador distinto al que usa normalmente y ofrécele una comprobación con una opción: "Ya inicié sesión, compruébalo". Una llamada que permanece esperando durante este momento indica que el inicio de sesión sigue en curso, no que el sistema se bloqueó.
3. Si no se abre nada o las herramientas de hosting no responden, un reinicio suele resolverlo. Es el único reinicio que puede requerir la Fase 10: "Cierra Claude Code por completo, ábrelo de nuevo, vuelve a este mismo chat y escribe continuar. Todo está guardado: los archivos del sitio, esta conversación y el resto del trabajo. Este reinicio es esperado, no es un problema". Si había un servidor de vista previa en ejecución, añade una frase honesta: el enlace de vista previa dejará de funcionar durante el reinicio, lo cual también es normal, y el sitio publicado está a punto de reemplazarlo. Cuando el usuario vuelva, activa de nuevo el inicio de sesión.
4. Confirma que la consulta de lectura devuelve datos reales antes de publicar cualquier cosa.

## Paso 1: definir la dirección y después actualizar las etiquetas Open Graph

Primero decide dónde vivirá el sitio. Revisa antes de preguntar: lista los dominios de la cuenta. Si uno corresponde claramente a la marca, propónlo por nombre y pregunta: "Veo [el dominio] en tu cuenta. ¿Quieres publicar el sitio ahí o prefieres usar primero una dirección temporal gratuita?". Nunca supongas la elección, aunque la coincidencia parezca obvia. El dominio pertenece al usuario y la decisión también. Un dominio registrado hace pocos minutos puede tardar en aparecer. Si no está en la lista, espera un minuto y vuelve a consultar antes de preguntar. Si ningún dominio corresponde al proyecto, pregunta si tiene uno en mente o si prefiere el subdominio temporal gratuito. El subdominio temporal es una opción real, no una alternativa inferior. Permite ver el sitio publicado hoy y conectar un dominio después.

Después actualiza las etiquetas. `og:image` y `og:url` necesitan URLs absolutas. Localiza el comentario `<!-- PASO DE DESPLIEGUE -->` que se dejó durante la construcción y actualiza ambas etiquetas con la URL elegida. Si se usará una dirección temporal, primero crea el sitio en el hosting y genera el subdominio gratuito para disponer de la URL. Hazlo ANTES de crear el ZIP, o la página publicada incluirá etiquetas de vista previa que no funcionan.

Realiza estos cambios con la herramienta de edición, nunca con un comando de reemplazo rápido en la terminal. Un script puede leer el archivo UTF-8 con una codificación incorrecta y dañar todos los caracteres especiales. Si eso ocurre, la recuperación está en `solucion-de-problemas.md`.

## Paso 2: comprimir el CONTENIDO, no la carpeta

El nivel superior del ZIP debe contener `index.html` y, a su lado, `assets/`. Si comprimes la carpeta del proyecto, todo queda anidado un nivel más abajo y el sitio puede mostrar un listado de directorio o un error 404.

Excluye las carpetas de revisión, los videos originales y cualquier archivo que no deba publicarse. Si los originales se guardaron fuera de la carpeta de despliegue, como se indicó, el ZIP contiene únicamente el contenido del sitio.

Ejemplo para Windows PowerShell, comprimiendo el contenido y no la carpeta:

```
Compress-Archive -Path .\index.html, .\assets -DestinationPath ..\site.zip -Force
```

Guarda también el ZIP fuera de la carpeta de despliegue.

## Paso 3: crear el sitio y publicarlo

1. Si el sitio todavía no existe en el hosting, créalo en la dirección elegida en el Paso 1. En la ruta temporal ya existe, porque el Paso 1 lo creó para obtener el subdominio antes de actualizar las etiquetas. Un dominio registrado en Hostinger se enlaza automáticamente, sin configuración adicional.
2. Publica el ZIP con la herramienta de despliegue estático.
3. Los archivos grandes no son un problema. Un despliegue que incluye un video principal puede tardar varios segundos por cada grupo de megabytes. No es instantáneo y es normal.

## Paso 4: comprobar personalmente el sitio publicado (antes de decir que está terminado)

- La página carga mediante HTTPS y devuelve un estado 200.
- La URL directa del video responde correctamente.
- La consola del navegador no muestra errores en la URL publicada.
- Recorre la portada con desplazamiento. La carga como Blob debe permitir búsquedas fluidas incluso en servidores sin soporte para solicitudes Range, pero hay que comprobarlo.

**Un dominio personalizado nuevo necesita un periodo de propagación.** El enlace del dominio suele ser rápido, pero el certificado HTTPS, el candado, puede tardar algunos minutos en emitirse cuando el dominio nunca ha servido un sitio, y a veces tarda más. Si el navegador muestra una advertencia de seguridad justo después del primer despliegue, significa que el certificado todavía se está generando, no que el sitio esté roto. Explícalo con claridad, espera unos minutos y vuelve a comprobarlo antes de declarar que está terminado. Los subdominios temporales incluyen HTTPS desde el principio.

## Paso 5: las pruebas de velocidad (medir y presentar)

Inmediatamente después de comprobar el sitio, mide la URL publicada y registra los resultados. Son la evidencia de que el sitio es rápido y el usuario puede necesitarlos. Mide:

- **El peso total de la página sin incluir el video.** Un proyecto saludable suele pesar decenas de KB.
- **El tiempo de carga de la página.** Un proyecto saludable carga en bastante menos de un segundo.
- **El tamaño del video y el tiempo que tarda en llegar detrás del indicador de carga.** Una toma única llega en pocos segundos con una conexión normal. Un recorrido encadenado tarda más. Mientras tanto, la página ya debe poder usarse por completo.

**Cómo medirlo de forma concreta.** Dos opciones listas para usar:

- Medición con curl en la URL publicada: `curl -s -o /dev/null -w "TTFB %{time_starttransfer}s, total %{time_total}s, %{size_download} bytes\n" https://la-url-publicada/` (en Windows usa `curl.exe`; también funciona `-o NUL`). Ejecútalo para la página y para la URL del video con el fin de obtener tamaños y tiempos.
- También puedes abrir la URL publicada con la herramienta de navegador y consultar el rendimiento: `performance.getEntriesByType('navigation')[0].loadEventEnd` para el tiempo de carga y `performance.getEntriesByType('resource')` para el `transferSize` de cada archivo.

Solo presenta mediciones reales. Nunca muestres una estimación como si fuera una prueba.

Presenta los números junto con el argumento estructural, porque en conjunto responden a la principal objeción frente a los sitios cinematográficos: "Se ve bonito, pero seguramente es lento y tiene un backend deficiente". Estos sitios son archivos estáticos simples. No hay framework, proceso de compilación ni código de servidor, así que no existe un backend que pueda fallar. El video se carga detrás de una imagen previa y un indicador de progreso honesto. Las pantallas pequeñas nunca descargan la versión pesada. Registra las cifras para que el usuario pueda compartirlas con su propio cliente.

## Paso 6: la prueba del usuario en dispositivos reales

Entrega el enlace publicado y pídele al usuario que pruebe el sitio en computadora Y en su teléfono, usando la conexión real y no solo `localhost`. Pídele que revise especialmente el desplazamiento al principio y al final de la portada en Chrome, donde las interrupciones suelen hacerse visibles primero. Sus ojos y su equipo detectan cosas que una auditoría no puede encontrar.

## Paso 7: iterar es económico

Modifica los archivos, vuelve a crear el ZIP y publica otra vez. Es un solo comando. No temas las rondas de ajustes, porque el ciclo no cuesta más que un minuto. Vuelve a comprobar la página publicada después de cada despliegue. Si la caché muestra la versión anterior, haz una recarga forzada o busca un texto que sepas que cambió.
