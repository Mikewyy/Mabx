# Recetas de ffmpeg

Comandos exactos para cada paso de procesamiento. Estos parámetros son valores recomendados y comprobados. El intervalo de fotogramas clave, en particular, marca la diferencia entre un desplazamiento fluido y uno entrecortado.

## Orden de carpetas

Primero crea la carpeta del proyecto. Elige un nombre para el sitio, normalmente el de la marca, en una ubicación acordada con el usuario. Dentro deben estar `index.html` y `assets/`, y hay que decirle al usuario dónde se guardó. Las generaciones originales y las copias para revisión se mantienen FUERA de la carpeta de despliegue, por ejemplo en `review/` junto al proyecto o un nivel arriba. Solo los archivos procesados entran en `assets/`. Nunca debe existir dentro de la carpeta de despliegue algo que no deba publicarse.

## Codificación para el desplazamiento (la más importante)

Vuelve a codificar el video original aprobado con un intervalo corto entre fotogramas clave. De lo contrario, el desplazamiento dará saltos porque el navegador solo puede buscar con precisión en esos fotogramas:

```
ffmpeg -i raw.mp4 -c:v libx264 -crf 18 -preset slow -g 8 -keyint_min 8 -pix_fmt yuv420p -movflags +faststart -an assets/hero-scrub.mp4
```

- `-g 8 -keyint_min 8`: un fotograma clave cada 8 fotogramas para que cada posición del desplazamiento se busque con fluidez.
- `-crf 18`: calidad visual limpia.
- `-movflags +faststart`: mueve los metadatos al principio para que la reproducción y el Blob puedan usarse inmediatamente.
- `-an`: elimina el audio. Un video controlado por desplazamiento no lo necesita.
- Busca un tamaño aproximado de 4 a 8 MB para un clip de 6 segundos a 1080p. Si queda muy por encima, aumenta `-crf` hacia 20 o 22 y revisa de nuevo la calidad.

### La compresión según el tipo de material

El material se divide en dos familias y cada una se comprime de forma opuesta:

**Los detalles abundantes ocultan artefactos.** Los videos llenos de partículas, tela o texturas en toda la pantalla esconden los defectos de compresión dentro del propio detalle, por lo que el valor CRF puede ser más agresivo. El detalle abundante de borde a borde suele tolerar un CRF de 25 a 26 y una reducción hasta unos 1700 píxeles de ancho, por ejemplo `-vf scale=1728:-2`. Son puntos de partida, no metas. Una textura de pantalla completa es el material más pesado y puede necesitar menos ancho o un CRF aún mayor.

**Los degradados suaves son lo contrario.** En lugar de ocultar defectos, forman bandas visibles, como escalones entre colores que deberían cambiar suavemente. Si comprimes demasiado un video con muchos degradados, los fotogramas tranquilos serán los primeros en dañarse. Revísalos de forma específica.

**El método siempre es el mismo:** empieza con los valores anteriores y modifica UNA variable a la vez, primero CRF y después el ancho. Revisa los peores fotogramas desplazándote, no solo pausando. En material con mucho detalle, algunos artefactos visibles en una imagen congelada desaparecen durante el movimiento. Ajusta el tamaño aproximadamente en proporción a la duración. Un clip de 6 segundos debería pesar cerca de un tercio de un video final de 18 segundos. Reduce la resolución antes de sacrificar la densidad de fotogramas clave y conserva idénticos los demás parámetros del desplazamiento: `-preset slow -g 8 -keyint_min 8 -pix_fmt yuv420p -movflags +faststart -an`.

## Recorte del final (cuando la observación es "termina antes")

La solución más económica para el final no es generar otra vez. Si la toma funciona hasta que el sujeto vuelve a moverse cerca del cierre, recorta el original en el último fotograma estable. La página relaciona el desplazamiento con el progreso, no con los segundos, así que un clip más corto no afecta nada. Extrae varios fotogramas cerca del segundo deseado, elige el que mejor se vea en reposo, considerando márgenes, rostro y composición, y después recorta y codifica para desplazamiento en una sola pasada:

```
ffmpeg -i raw.mp4 -t 4.3 -c:v libx264 -crf 18 -preset slow -g 8 -keyint_min 8 -pix_fmt yuv420p -movflags +faststart -an assets/hero-scrub.mp4
```

Después vuelve a obtener la imagen inicial y el fotograma final. Revisa otra vez el nuevo cierre con el encabezado simulado encima, porque ese fotograma recortado será la composición donde descansa la página. Solo genera de nuevo pagando el costo completo cuando no exista ningún fotograma estable.

## Comprobación objetiva del reposo final con un comando

No hace falta decidir a simple vista si el final se detiene de verdad. Mide el movimiento por fotograma: compara cada fotograma con el anterior y lee el brillo promedio de esa diferencia para obtener una curva de movimiento:

```
ffmpeg -i raw.mp4 -vf "tblend=all_mode=difference,signalstats,metadata=print:key=lavfi.signalstats.YAVG" -f null -
```

Cada fotograma imprime una línea `YAVG`. Un valor más alto significa que cambió más respecto al anterior. Observa el final de la curva. Una llegada sube y luego vuelve cerca del nivel inicial. Un movimiento continuo permanece alto hasta el final. Este comando sustituye la estimación visual y permite decidir si se necesita el recorte anterior.

## Imagen inicial y fotograma final

```
ffmpeg -i assets/hero-scrub.mp4 -frames:v 1 -q:v 2 assets/hero-poster.jpg
ffmpeg -sseof -0.1 -i assets/hero-scrub.mp4 -update 1 -frames:v 1 -q:v 2 assets/hero-ending.jpg
```

El fotograma final es un recurso de diseño gratuito y completamente alineado con la marca. Reutilízalo en una sección inferior.

## Extracción de fotogramas para revisión (antes de solicitar aprobación)

Extrae los fotogramas inicial, central y final del video ORIGINAL y revísalos: anatomía, transiciones y si el cierre se queda realmente en reposo. Para un clip de 6 segundos:

```
ffmpeg -ss 0 -i raw.mp4 -frames:v 1 -q:v 2 review/frame-start.jpg
ffmpeg -ss 3 -i raw.mp4 -frames:v 1 -q:v 2 review/frame-mid.jpg
ffmpeg -sseof -0.1 -i raw.mp4 -update 1 -frames:v 1 -q:v 2 review/frame-end.jpg
```

## Fotograma para encadenar (calidad completa, nunca calidad de revisión)

El fotograma que se convertirá en el `start_image` del siguiente segmento debe ser un PNG de calidad completa. Los JPG de revisión con `-q:v 2` sirven solo para inspección. Si se utilizan para encadenar, la compresión se acumula en cada segmento posterior:

```
ffmpeg -sseof -0.1 -i seg.mp4 -update 1 -frames:v 1 -q:v 1 final.png
```

Este PNG se carga mediante `media_upload` y `media_confirm`. El proceso completo está en `leyes-de-prompts.md`. El identificador del archivo confirmado se convierte en el `start_image` del siguiente segmento.

## Concatenación de segmentos (recorridos encadenados de Nivel 2)

**Opción recomendada: unir los originales y codificar exactamente una vez.** Alimenta los segmentos ORIGINALES a un solo filtro y aplica la codificación para desplazamiento una vez al resultado unido. Una única codificación evita incompatibilidades porque no hay parámetros separados que deban coincidir:

```
ffmpeg -i seg1-raw.mp4 -i seg2-raw.mp4 -i seg3-raw.mp4 -filter_complex "[0:v][1:v][2:v]concat=n=3:v=1:a=0[v]" -map "[v]" -c:v libx264 -crf 25 -preset slow -g 8 -keyint_min 8 -pix_fmt yuv420p -movflags +faststart -an assets/hero-scrub.mp4
```

Define `-crf` con base en la sección de compresión anterior. Usa 18 como punto de partida normal, valores más agresivos y una reducción de tamaño para partículas o texturas abundantes, y valores más suaves para videos con degradados. El `-crf 25` del ejemplo corresponde a material con muchos detalles.

**Alternativa cuando los originales ya no están disponibles:** codifica cada segmento con parámetros IDÉNTICOS, usando el mismo códec, resolución, velocidad de fotogramas, formato de píxel y `-g 8`, y después concatena sin pérdida con el demultiplexor concat.

`concat-list.txt`:

```
file 'seg1-scrub.mp4'
file 'seg2-scrub.mp4'
file 'seg3-scrub.mp4'
```

```
ffmpeg -f concat -safe 0 -i concat-list.txt -c copy assets/hero-scrub.mp4
```

Si la unión con el demultiplexor falla durante la reproducción, los parámetros no eran realmente idénticos. Vuelve a ejecutar el mismo comando de codificación para todos los segmentos desde sus fuentes originales y concatena otra vez. No ocultes una unión defectuosa volviendo a codificar el archivo final con menor calidad. Si todavía tienes los originales, utiliza la ruta de una sola codificación y elimina por completo este tipo de error.

## Rescate con fundido cruzado (cuando se nota una unión)

Si una cadena ya generada muestra un corte visible aunque el movimiento continúe, normalmente porque la textura se reinterpretó en la unión, sustituye la concatenación directa por un fundido cruzado breve con `xfade`. La ley de las uniones está en `leyes-de-prompts.md`. Un cuarto de segundo es un punto de partida comprobado. Al desplazarse, el visitante lo percibe como un cambio de la superficie y no como un corte.

El punto de inicio del fundido es la duración de la primera entrada menos la duración del fundido. Para dos segmentos de 6 segundos con un fundido de 0.25 segundos:

```
ffmpeg -i seg1-raw.mp4 -i seg2-raw.mp4 -filter_complex "[0:v][1:v]xfade=transition=fade:duration=0.25:offset=5.75[v]" -map "[v]" -c:v libx264 -crf 18 -preset slow -g 8 -keyint_min 8 -pix_fmt yuv420p -movflags +faststart -an assets/hero-scrub.mp4
```

Para tres segmentos, encadena los fundidos. Cada desplazamiento posterior es la duración acumulada menos el fundido, por ejemplo `6 + 6 - 0.25 - 0.25 = 11.5`:

```
ffmpeg -i seg1-raw.mp4 -i seg2-raw.mp4 -i seg3-raw.mp4 -filter_complex "[0:v][1:v]xfade=transition=fade:duration=0.25:offset=5.75[a];[a][2:v]xfade=transition=fade:duration=0.25:offset=11.5[v]" -map "[v]" -c:v libx264 -crf 18 -preset slow -g 8 -keyint_min 8 -pix_fmt yuv420p -movflags +faststart -an assets/hero-scrub.mp4
```

Define `-crf` y cualquier reducción de tamaño según la sección de compresión. Sigue siendo una sola codificación, por lo que las uniones no pueden tener parámetros distintos. Cada fundido reduce la duración total por ese mismo tiempo. La página no lo nota porque todo funciona por progreso, no por segundos. Comprueba cada unión desplazándote hacia adelante y hacia atrás, no reproduciendo a velocidad normal. Un sitio de este tipo se consume mediante desplazamiento y ahí es donde una unión se revela o desaparece.

## Tamaño de imágenes para la web

Reduce las imágenes de apoyo a unos 1920 píxeles de ancho con UNA sola compresión limpia. Muchos servicios de hosting vuelven a comprimir las imágenes, así que sube archivos grandes y limpios para que el proceso del servidor sea la única compresión con pérdida. Los videos normalmente pasan sin cambios:

```
ffmpeg -i raw-still.png -vf scale=1920:-2 -q:v 2 assets/section-name.jpg
```

`-q:v 2` ofrece una calidad JPEG casi transparente. `-2` conserva una altura par, necesaria para algunos codificadores. Las capturas de pantalla y otras imágenes de interfaz con bordes definidos permanecen en PNG o WebP sin pérdida. La conversión a JPEG es para fotografías.

## Comprobar después de cada codificación

Reproduce el resultado o extrae fotogramas antes de utilizarlo. Detectar ahora una codificación fallida no cuesta nada. Encontrarla después de publicar obliga a realizar otro despliegue.
