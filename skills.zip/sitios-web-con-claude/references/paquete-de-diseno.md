# El paquete de diseño

Es el único entregable del ciclo de Dirección Creativa de la Fase 5. Un documento que reúne cada decisión creativa, se escribe completo ANTES de generar cualquier recurso y se usa durante la construcción en la Fase 8. Quien lo reciba no debe necesitar nada más para construir la página correcta.

Lo gobiernan dos reglas:

- **Cada línea de texto del paquete se publica literalmente.** El paquete es donde se redacta. La construcción es donde se conecta todo. Durante la construcción se colocan exactamente las líneas aprobadas y nunca se parafrasean.
- **Los números son puntos de partida.** Los rangos de las bandas y los valores de meseta se presentan como puntos de partida. La prueba de desplazamiento de `flujo-de-desplazamiento.md` los valida después, y los rangos se ajustan si la prueba lo exige.

El Nivel 1 utiliza el mismo paquete, pero reducido: menos bandas y las mismas secciones.

## 1. La premisa de la marca

Un párrafo breve basado en UNA palabra o idea real del mundo de la marca. Todo el sitio enseña y vende esa única idea. Cada sección, el momento interactivo y la frase final deben servir a esa premisa. Si una sección no la apoya, no pertenece a la página.

## 2. La paleta como variables CSS

Se obtiene del mundo visual del video, para que la página y las imágenes se sientan como un mismo lugar. Antes de generar, el paquete define la dirección de color a partir del storyboard. Los valores exactos se finalizan a partir del material aprobado, después de la aprobación del video. Usa nombres por función, listos para pegar en el sitio:

```css
:root{
  --canvas:#___;        /* fondo de la página, teñido hacia el color del video, nunca negro o blanco puros */
  --panel:#___;         /* tarjetas y superficies elevadas */
  --accent:#___;        /* llamada a la acción y énfasis poco frecuentes */
  --accent-hover:#___;  /* estado hover del acento */
  --accent-muted:#___;  /* acento sutil: bordes, resplandores y partículas */
  --text-secondary:#___;
  --text-primary:#___;
}
```

## 3. El trío tipográfico

Una tipografía de títulos con personalidad, una tipografía discreta para el cuerpo y una monoespaciada para etiquetas pequeñas. Nunca uses Inter o Roboto como tipografía de títulos. Elige fuentes del propio mundo de la marca, no una opción automática o habitual. Especifica cada fuente y los pesos exactos que se usarán.

## 4. El mapa de bandas

Una tabla con una fila por cada banda de la portada:

| Banda | Rango (punto de partida) | Momento del video | Texto (literal) | Entrada |
|---|---|---|---|---|
| 1 | 0.00 a 0.14 | lo que está haciendo el video | "Las palabras exactas." | una entrada con nombre |
| 2 | 0.16 a 0.32 | ... | "..." | ... |

- **Rango:** punto de partida expresado como progreso del desplazamiento, que se valida después con la prueba de desplazamiento.
- **Momento del video:** lo que se ve mientras la banda está activa, para mantener libre el área de acción.
- **Texto:** las palabras finales exactas, escritas con la voz de la marca.
- **Entrada:** una entrada con nombre para cada banda que refleje el momento del video, según el principio de eco de `flujo-de-desplazamiento.md`.

## 5. El bloque de texto para la portada estática

El texto compuesto para quienes reciben la portada estática, como teléfonos o personas con movimiento reducido: título, subtítulo y llamada a la acción, escritos para funcionar sobre la imagen inicial o final sin depender del recorrido animado.

## 6. La estructura debajo de la portada

Las secciones que aparecen después del punto de llegada, en orden y con su texto literal. Todas conducen hacia UNA sola llamada a la acción. La estructura incluye:

- El único momento interactivo y la sección donde aparece.
- Las preguntas frecuentes, que responden con las propias palabras de los compradores a las objeciones reales encontradas durante la investigación.
- Las citas o testimonios.
- Los textos pequeños del formulario: etiquetas, textos de ejemplo, nombre del botón y estado de éxito, además de la opción elegida para procesar formularios en un sitio estático. Puede ser un estado de éxito solo con JavaScript, un enlace `mailto`, un servicio gratuito de formularios o ningún formulario. Las opciones completas están en la Fase 8 de la skill.
- El pie de página, con una aclaración cuando la marca sea ficticia.

## 7. El plan de elementos vectoriales

Los elementos SVG que se dibujarán a mano, como motivos, líneas que se trazan solas y divisores. Incluye también las partículas sutiles y el lugar de cada elemento en la página. Todo debe respetar la preferencia de movimiento reducido: mostrar los estados finales y detener las animaciones controladas.

## 8. La lista de ingeniería

Nombra el estándar completo para evitar que la construcción recuerde solo una parte: carga como Blob con indicador, interpolación normalizada por tiempo, búsquedas bloqueadas para evitar superposición, escrituras en el DOM solo cuando hay cambios, ritmo de bandas con la prueba de desplazamiento, sistema de legibilidad de cuatro capas, cinco condiciones de portada estática activas con detectores de cambios, sitio completo aun sin video y el nivel mínimo de calidad. Todo está en `flujo-de-desplazamiento.md`, junto con el estándar de animación para todo el sitio de la Fase 8 de la skill.

## 9. La línea de control del texto

Termina el paquete con esta condición para que la construcción la herede: cada línea visible para el visitante se publica literalmente y la página debe superar el control de la Fase 9 antes de que alguien la vea. Debe haber cero rayas largas, cero palabras corporativas genéricas y una revisión adicional del cuerpo de texto para detectar señales de redacción automática. Los recursos de marca escritos deliberadamente en este paquete, como una tríada diseñada o un golpe entrecortado planeado, son parte del trabajo creativo y se conservan. La revisión busca únicamente lo que apareció sin intención.
