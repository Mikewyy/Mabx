# Solución de problemas: síntoma → causa → solución

Cada caso ocurrió en un proyecto real. Consulta esta guía antes de inventar un diagnóstico.

## Generación

| Síntoma | Causa | Solución |
|---|---|---|
| El generador sugiere un preset en lugar de crear la toma | Relacionó el prompt con uno de sus estilos predefinidos | Recházalo y vuelve a intentar con el prompt literal. Tu toma diseñada es mejor que un estilo genérico |
| Aparece un logotipo o marca real en la imagen generada | La IA introdujo una marca registrada | Corrígela con una edición económica de imagen antes de animar. Nunca animes un fotograma con una marca registrada no autorizada |
| La transformación "parece dos videos distintos" | La trayectoria se interrumpió durante el cambio | Mantén un solo vector continuo durante la transición, con la misma dirección, posición y velocidad. Una solución mejor es elegir un concepto con un solo sujeto |
| El sujeto parece congelado o sin vida | El prompt lo estabilizó demasiado para proteger la trayectoria | Fija la trayectoria y libera el cuerpo. Conserva el recorrido rígido, pero exige movimiento natural en el sujeto y vida ambiental en la escena |
| El cruce de una superficie, como entrar al agua o atravesar vidrio, parece falso | El paso fue demasiado limpio | Describe el momento físico sobre el lente: salpicadura, gotas o un instante de desenfoque |
| El producto principal parece provisional | Es un objeto genérico sin marca y visto a distancia | Aplica el logotipo mediante edición de imagen antes de animar o escribe un final más cercano para que el diseño del objeto tenga protagonismo |
| Tres videos fallidos con el mismo concepto | El problema está en el concepto, no en el prompt | Deja de ajustar el prompt y cambia el concepto. Las leyes ayudan a prever cuáles funcionan al primer intento |
| La toma es buena, pero el final no queda en reposo porque el sujeto vuelve a moverse | El modelo pasó de largo el punto de llegada y siguió animando | No generes de nuevo primero. Recorta el original en el último fotograma estable y codifica para desplazamiento en una sola pasada, según `recetas-ffmpeg.md`. La página utiliza progreso y no segundos, así que acortar el clip no cuesta nada |
| El recorrido encadenado falla en la unión entre segmentos | Los parámetros de codificación no eran idénticos o el vector de movimiento se interrumpió | Vuelve a codificar todos los segmentos con exactamente el mismo comando y concatena otra vez. Si el movimiento salta, el prompt del segmento siguiente no continuó la dirección y velocidad anteriores |
| Hay un corte visible entre dos segmentos aunque el movimiento continúa | Cada generación vuelve a interpretar los detalles finos de la textura, por lo que una unión en reposo sobre tejido, grano o piel se nota | La próxima vez diseña cada unión dentro del movimiento o en un momento que justifique refrescar la textura, según la ley de las uniones de `leyes-de-prompts.md`. Para una cadena ya generada, usa el fundido cruzado de `recetas-ffmpeg.md` |
| Un trabajo abstracto e inocente aparece marcado como NSFW | El filtro de seguridad interpretó mal lenguaje sensorial abstracto, como formas luminosas o líquidos alrededor de un objeto | Revisa primero el saldo. Los trabajos bloqueados no deben cobrar créditos. Después repite con el mismo fotograma inicial y un prompt redactado como fotografía comercial de producto: nombra pronto el producto, describe objetos en vez de sensaciones y conserva el diseño de la toma |

## Portada controlada por desplazamiento

| Síntoma | Causa | Solución |
|---|---|---|
| El video no responde al desplazamiento en el sitio publicado, pero sí funciona localmente | El servidor no admite descargas parciales HTTP Range, por lo que las búsquedas regresan a cero | Carga el video completo como Blob y reproduce la URL de objeto, según `flujo-de-desplazamiento.md`. Funciona en cualquier servidor |
| El desplazamiento se siente entrecortado al principio y al final de la portada, especialmente en Chrome | Se acumulan búsquedas sin bloqueo y escrituras en el DOM en cada fotograma | Aplica el bloqueo de búsquedas y escribe en el DOM solo cuando cambie un valor, según `flujo-de-desplazamiento.md` |
| Sigue entrecortado después de aplicar esos controles | El intervalo de fotogramas clave del video es demasiado largo | Vuelve a codificar con `-g 8 -keyint_min 8`, según `recetas-ffmpeg.md` |
| El desplazamiento se congela para siempre a mitad del recorrido | La bandera de búsqueda ocupada quedó bloqueada porque una búsqueda falló y nunca disparó `seeked` | Restablece la bandera y limpia el objetivo pendiente en el evento `error` del video. El patrón seguro está en `flujo-de-desplazamiento.md` |
| Los teléfonos descargan un video o una imagen previa que nunca muestran | La imagen previa se definió en HTML o la carga del video quedó fuera de la condición de portada estática | Asigna la imagen previa con JavaScript dentro de la misma ruta condicionada que carga el video |
| La portada estática aparece en computadora o el video se carga en teléfonos | Las cinco condiciones difieren entre CSS y JavaScript | Usa exactamente las mismas cinco consultas en ambos lugares, según `flujo-de-desplazamiento.md` |
| La página se rompe cuando el video no carga | No existe una ruta de error | Oculta el video fallido sobre el fondo de imagen en el evento `error`. La página debe estar completa sin video |
| Las capturas del sitio muestran la imagen previa o un escenario vacío donde debería verse el video, aunque funciona en un navegador real | La capa de composición promovida del video no aparece dentro de las capturas de navegadores integrados | Comprueba el desplazamiento a través del DOM y no de los píxeles: inspecciona las variables `--k`, opacidades y transformaciones del texto y `currentTime` en varias posiciones. También puedes verlo en un navegador real. Una capa promovida en blanco dentro de una captura no significa que el sitio esté roto |
| La página se ve totalmente inmóvil en la vista previa: no hay imagen, todas las bandas están en opacidad 0, el video no busca y el panel indica que está oculto | Un panel oculto o no visible deja de componer la página y `requestAnimationFrame` no se ejecuta. Como todo depende de ese ciclo, el DOM también se congela | Deja de usar el panel y controla de forma headless el Chrome instalado en el equipo. La receta completa aparece debajo de esta tabla. Revisar el DOM como en el caso anterior no sirve porque aquí el propio DOM está congelado |
| La portada queda vacía, sin imagen ni textos, al girar el dispositivo o cambiar el tamaño de la ventana | JavaScript decidió una sola vez entre portada estática o animada, mientras CSS siguió evaluando las condiciones | Activa y desactiva el desplazamiento mediante detectores de cambios en las cinco consultas. El patrón está en `flujo-de-desplazamiento.md` |
| Al abrir `index.html` con doble clic aparece una portada fija y el video nunca carga | Los navegadores bloquean `fetch` en URLs `file://`, por lo que el cargador Blob utiliza intencionalmente la alternativa estática | Ese es el estado de respaldo diseñado y debe verse completo. Para probar el desplazamiento, sirve la carpeta con un comando como `npx http-server` o `python -m http.server` y abre `localhost`. El hosting publicado sirve el video normalmente |

### Receta de Chrome headless (cuando el panel de vista previa no funciona)

Cuando el panel está oculto o falla, comprueba el sitio con el Chrome instalado en el equipo, ejecutado de forma headless mediante el protocolo DevTools. Es el canal de control remoto incluido en Chrome. No necesita instalaciones ni paquetes:

1. Inicia Chrome con `--headless=new --disable-gpu --remote-debugging-port=9222 --user-data-dir=<una carpeta temporal> --hide-scrollbars`.
2. Desde Node, cuya versión 22 o posterior incluye un WebSocket global y no necesita dependencias, haz una solicitud GET a `http://127.0.0.1:9222/json/list`, toma el valor `webSocketDebuggerUrl` del objetivo y conéctate.
3. Mediante ese socket, controla la página con comandos del protocolo: `Page.navigate`, `Page.captureScreenshot`, `Runtime.evaluate`, `Emulation.setDeviceMetricsOverride`, `Emulation.setTouchEmulationEnabled`, `Emulation.setEmulatedMedia`, `Network.setBlockedURLs` e `Input.dispatchMouseEvent`.

Un detalle importante: `Emulation.setTouchEmulationEnabled` rechaza un `maxTouchPoints` igual a 0. Envía siempre 5 y controla el comportamiento mediante la bandera `enabled`.

Además de servir como rescate, esta ruta permite realizar pruebas reales de emulación táctil, cambios de medios en vivo, bloqueo de URLs y clics reales. Se enumeran en la lista de comprobación de `flujo-de-desplazamiento.md`.

## La página

| Síntoma | Causa | Solución |
|---|---|---|
| Una animación de entrada nunca se reproduce y el elemento simplemente aparece | Una regla posterior ganó en la cascada y anuló el estado inicial | Prefija los estados inicial y final con la clase contenedora, como `.card .part` y `.card.in .part`, y comprueba cada entrada |
| Los efectos hover de los elementos segundo y tercero de una cuadrícula escalonada responden tarde aunque la entrada terminó | La regla que elimina `transition-delay` tiene menor especificidad que las reglas `:nth-child` que intenta retirar. `:nth-child` cuenta como una clase y la limpieza no se aplica | Haz que el selector de limpieza iguale o supere la especificidad, repite `:nth-child` o usa `!important` en el retraso `0s`. Después compruébalo pasando el cursor sobre los elementos posteriores |
| Un estilo controlado por desplazamiento deja de responder después de la animación de entrada | `animation-fill-mode: forwards` lo sobrescribe de forma permanente | Coloca la animación de entrada en el elemento padre y el estilo dinámico en un hijo |
| Un ciclo de fondo parpadea o salta al comenzar | Retraso positivo de la animación | Usa retrasos negativos, como `-1.2s`, para que el ciclo aparezca a mitad de recorrido desde el primer dibujo |
| Se cortan las colas de letras como g, y o p | El texto está enmascarado o recortado sin espacio adicional | Añade relleno basado en `em` y márgenes negativos equivalentes alrededor de la máscara, según `flujo-de-desplazamiento.md` |
| La página se puede arrastrar o desplazar hacia los lados | Solo usa `overflow-x: hidden` o hay una decoración fuera del borde | Declara primero `hidden` como respaldo y después `overflow-x: clip` tanto en `html` como en `body` |
| Los efectos hover empiezan a saltar después de ejecutar un script | JavaScript reemplazó `el.style.transition` | Activa una clase que declare la transición combinada completa |
| Un elemento móvil queda fuera de la pantalla con movimiento reducido | Una regla general `transform: none !important` eliminó también su transformación de posición | Vuelve a declarar las transformaciones de posición por punto de quiebre dentro del bloque de movimiento reducido |
| Un letrero continuo muestra un hueco al reiniciar el ciclo | La pista es más corta que la pantalla compatible más ancha | Duplica los elementos hasta que cada pista supere aproximadamente 2560 píxeles |
| Las animaciones continúan cuando la pestaña está oculta o la sección está fuera de pantalla | Ciclos libres sin control | Limita las reglas a una clase activada por IntersectionObserver. En `visibilitychange`, activa una clase en `body` con `body.paused *, body.paused *::before, body.paused *::after { animation-play-state: paused !important }`. Los ciclos rAF deben descansar al converger |
| Una pausa escrita en el contenedor no detiene las animaciones internas | `animation-play-state` no se hereda, por lo que el valor del padre o un `inherit` no llega a los hijos ni a sus pseudo-elementos | Usa el patrón de clase en `body` anterior, que afecta directamente a cada elemento y pseudo-elemento |

## Despliegue

| Síntoma | Causa | Solución |
|---|---|---|
| El sitio muestra un listado de directorio o un error 404 | El ZIP contiene la carpeta del proyecto y no su contenido | Vuelve a comprimir con `index.html` en el nivel superior |
| Las imágenes se ven suaves en línea, pero nítidas localmente | El hosting cambia el tamaño y vuelve a comprimir las imágenes | Sube archivos más grandes y limpios, de unos 1920 píxeles de ancho y con una sola compresión de alta calidad, para que la del servidor sea el único proceso con pérdida |
| Las vistas previas de enlaces no muestran imagen o usan una URL incorrecta | Las etiquetas Open Graph todavía contienen valores provisionales | Actualiza `og:image` y `og:url` con la URL absoluta publicada en el comentario `<!-- PASO DE DESPLIEGUE -->`, vuelve a crear el ZIP y publica otra vez |
| El sitio sigue mostrando la versión anterior después de publicar | Caché | Haz una recarga forzada o busca una cadena que sepas que cambió |
| Los videos originales o archivos de revisión aparecen publicados | Estaban dentro de la carpeta de despliegue al crear el ZIP | Mantén siempre los originales y revisiones FUERA de la carpeta de despliegue |
| Los caracteres especiales se convierten en símbolos extraños después de un reemplazo automático | Un comando de terminal leyó el archivo UTF-8 con una codificación incorrecta y guardó el daño | No modifiques archivos del sitio con lecturas y escrituras simples de terminal. Usa la herramienta de edición para las etiquetas Open Graph y cualquier cambio de texto, o especifica UTF-8 tanto al leer como al escribir. Si ya ocurrió, lee el archivo dañado como UTF-8, codifica ese texto como bytes Windows-1252, decodifica esos bytes como UTF-8, guarda en UTF-8, revisa los caracteres y vuelve a publicar |

## Configuración

| Síntoma | Causa | Solución |
|---|---|---|
| Las herramientas de Hostinger no aparecen después de agregar el conector o la página de inicio de sesión no se abre | Un conector local recién agregado a veces se carga hasta el siguiente inicio de la aplicación | Cierra Claude Code por completo, vuelve a abrirlo, regresa al mismo chat y activa otra vez el inicio de sesión |
| El sitio parece congelado en el panel lateral de vista previa | El panel integrado tiene dificultades con páginas que controlan video mediante desplazamiento | Abre el enlace de `localhost` en un navegador real. Esa es la vista previa correcta |
| El comando del conector de Hostinger falla en Windows | Se usó `npx` en lugar de `npx.cmd` | En Windows usa `claude mcp add hostinger -- npx.cmd -y hostinger-api-mcp` |
| El inicio de sesión de Hostinger parece no avanzar | La autorización se abrió en un navegador distinto al habitual | Avísalo con anticipación y pídele que revise los demás navegadores |
| Las herramientas de Higgsfield no aparecen justo después de conectarlo | Un conector recién agregado puede cargarse hasta el siguiente inicio | Cierra Claude Code por completo, ábrelo de nuevo, regresa al mismo chat y comprueba otra vez |
| El conector de Higgsfield indica que necesita autenticación | El inicio de sesión no se completó durante la instalación | Termínalo desde el panel de conectores. El navegador abre Higgsfield para autorizar una vez. Después comprueba el saldo |
| Las herramientas de Higgsfield aparecen, pero las llamadas fallan | El conector se agregó sin autorización o no quedan créditos | Repite el inicio de sesión y verifica con una consulta de saldo que devuelva cifras reales |
| El usuario dice que terminó un paso, pero el siguiente falla | Se tomó "listo" como si fuera una comprobación | Nunca lo es. Revisa personalmente el sistema después de cada paso antes de avanzar |
| ffmpeg o Node.js no se instalan en una Mac | Homebrew no está instalado, por lo que los comandos `brew` no pueden ejecutarse, y la seguridad de macOS suele bloquear un binario descargado | Pide al usuario que instale Homebrew con el comando de `brew.sh`, pegado en Terminal. Le solicitará la contraseña de su Mac. Después vuelve a ejecutar las instalaciones y comprueba cada herramienta |
| Claude omite la lista de configuración y salta directamente a preguntas sobre la marca o el diseño | El ZIP de la skill nunca se extrajo ni se leyó completo. Esto es común cuando se arrastra al chat y los archivos no entran en la conversación | Extrae el ZIP en el espacio del proyecto, lee `SKILL.md` y todas las referencias de principio a fin, y vuelve a empezar en la Fase 1. La lista de configuración es siempre el primer mensaje que ve el usuario |
| Todas las llamadas de hosting se quedan esperando durante una sesión larga y se abre repetidamente una pestaña de inicio de sesión | El conector de hosting perdió la sesión y cada llamada espera una nueva autorización | Completa una vez el inicio de sesión en la pestaña abierta. Si la ventana falla, reinicia por completo la aplicación y autoriza una vez. Los archivos y el sitio publicado no se ven afectados |

**La regla de dos bloqueos, para cualquier herramienta:** si la misma herramienta o subsistema se queda sin responder dos veces seguidas, considéralo fuera de servicio. Deja de reintentar, explica el problema y reinicia. Nunca hagas una tercera llamada a un subsistema bloqueado. Es distinto de una generación lenta. Un trabajo que informa avances sigue funcionando aunque tarde. Esta regla solo cubre una llamada que no responde ni muestra progreso.
