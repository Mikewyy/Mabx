# Leyes del video principal y construcción de prompts

Diseña cada toma con estas leyes ANTES de generar. Ayudan a predecir qué conceptos funcionarán al primer intento y cuáles consumirán créditos. Cada regla surgió de un proyecto real que tuvo éxito gracias a ella o falló por no aplicarla.

## Las doce leyes

1. **El movimiento coincide con el desplazamiento.** Desplazarse hacia abajo debe sentirse como bajar, abrir o llegar: verter, descender, desarmar o acercarse. Pregúntate con cada concepto: "Cuando el visitante baja por la página, ¿este movimiento se siente como ir hacia abajo?". Un sujeto que vuela HACIA ARRIBA mientras el visitante baja se opone a la página y siempre pierde.

2. **Un sujeto, un movimiento continuo y ningún corte.** Un solo sujeto recorre un único trayecto. No pidas al video con IA que convierta una cosa en otra distinta. Las transformaciones entre dos sujetos son las tomas más difíciles y consumen mucho presupuesto. Si el usuario insiste, oculta el cambio dentro de un destello o una nube, conserva una trayectoria continua, con la misma dirección, posición y velocidad a ambos lados del cambio, y cuenta con que quizá necesites repetir.

3. **Fija la trayectoria y libera el cuerpo.** El recorrido se mantiene rígido, pero el sujeto debe sentirse vivo: movimiento natural, ondulación y pequeños ajustes. La escena también necesita vida: vapor flotando, nubes en movimiento o luz cambiante. Nunca estabilices una toma congelando al sujeto. Un sujeto inmóvil sobre una trayectoria limpia parece material sin vida.

4. **Planea primero el final.** La página se detiene en el último fotograma, así que descríbelo de forma explícita como una llegada bien compuesta y satisfactoria: la taza descansando sobre la barra, el producto armado o el destino alcanzado. Un final incómodo produce un sitio incómodo. Si el final presenta un producto, deja un margen generoso arriba y abajo de todo el objeto. El encabezado del sitio se superpone en la parte superior y el recorte con `cover` se come los bordes en pantallas anchas o bajas. Un producto cortado en la parte superior parece un error. Pegado al menú se siente saturado. Otra opción evita por completo este problema: terminar en una textura de borde a borde, sin elementos que puedan recortarse, deja una zona segura para texto en cualquier pantalla. Antes de aprobar, revisa el último fotograma con una simulación del encabezado encima, tanto en una ventana ancha como en una baja.

5. **Elige sujetos tolerantes a los errores.** Los fluidos, la niebla, el vapor, la luz, las telas y las siluetas lejanas suelen generarse muy bien. Cualquier objeto cuya anatomía exacta sea conocida por todos, como controles, teclados, manos o animales familiares en primer plano, delatará inmediatamente los errores. Mantén los detalles riesgosos a distancia, simples y en movimiento.

6. **Prefiere un eje de movimiento vertical.** Un recorrido recto hacia arriba o abajo coincide directamente con el eje del desplazamiento, por lo que la revelación acompaña a la página en ambas direcciones. No es obligatorio, pero si dos conceptos son igual de buenos, elige el vertical.

7. **Compón para el diseño.** Durante la creación del concepto, decide dónde estará la acción dentro del encuadre y deja espacio negativo intencional para los textos y la historia. El carril de acción permanece libre y las palabras lo rodean.

8. **Haz creíbles los cruces de superficies.** Cuando la cámara atraviesa una superficie, como entrar al agua, pasar por niebla o cruzar vidrio, describe en el prompt el momento físico sobre el lente: una salpicadura, gotas en el lente o un instante de desenfoque. Atravesar una superficie de forma demasiado limpia parece falso. El desorden produce realismo.

9. **Si la portada muestra un producto, añade la marca o encuádralo de cerca.** Un objeto genérico sin marca y visto a distancia parece un elemento provisional. Aplica el logotipo mediante edición de imagen antes de animar o escribe un final que acerque lo suficiente el objeto para que su diseño tenga protagonismo.

10. **El texto sobre el video debe ganarse su legibilidad.** Un video detrás de las letras es un fondo cambiante que no controlas fotograma por fotograma. Cada banda de texto necesita un sistema de legibilidad: una veladura local, es decir, un degradado oscuro suave detrás de las palabras, que se intensifica solo mientras esa banda está activa; una sombra de texto real; y una revisión de contraste contra el PEOR fotograma de la banda, nunca contra el promedio. Coloca cada banda en la región más tranquila de sus fotogramas. Si una línea no se puede leer de un vistazo durante el momento más cargado de su banda, no pasa la prueba. El sistema completo, con código y auditoría, está en `flujo-de-desplazamiento.md`.

11. **Mide el ritmo del texto en distancia de desplazamiento, no en segundos.** Un sitio con desplazamiento se lee mediante movimientos de la rueda o del dedo, no se reproduce a 24 fotogramas por segundo. Da a cada texto una meseta larga de visibilidad total, que ocupe la mayor parte de la banda y sobreviva varios movimientos normales, con transiciones suaves y cortas en los extremos. Así el lector no verá un texto aparecer y desaparecer entre dos movimientos ni tendrá que detenerse por completo para alcanzarlo. Prueba el mapa desplazándote como un visitante real, no arrastrando lentamente. Los números y la prueba están en `flujo-de-desplazamiento.md`.

12. **Las protecciones permanentes.** Escribe "sin texto, sin logotipos y sin letras en ninguna parte" en cada prompt de imagen y video. Rechaza los presets sugeridos por el generador cuando ya tengas una toma diseñada. Nunca construyas el sitio alrededor de un video que el usuario no haya aprobado. Se permite avanzar en silencio con la estructura mientras termina la generación, pero no se muestra ni se finaliza nada hasta que el video pase su aprobación.

## Construcción de prompts

### Plantilla del fotograma inicial (imagen 16:9, 2K, alrededor de 2 créditos)

Compón la imagen como el primer fotograma del movimiento, con el sujeto colocado de modo que el recorrido pueda comenzar.

```
[SUJETO] en [POSICIÓN DENTRO DEL ENCUADRE], compuesto como el primer instante
de un movimiento que [RECORRIDO EN UNA SOLA FRASE]. [ILUMINACIÓN: fuente,
dirección y ambiente]. [PALETA: los tres a cinco colores de la marca descritos
como materiales y luz, no como códigos hexadecimales]. [ATMÓSFERA: la vida
ambiental de la escena]. Espacio negativo intencional en [LUGAR DONDE IRÁN LOS
TEXTOS]. Cinematográfico, fotorrealista, 16:9. Sin texto, sin logotipos y sin
letras en ninguna parte.
```

**La trampa al describir el espacio negativo: nunca llames oscuridad o vacío al espacio libre.** Cuando reserves espacio para los textos, describe la escena como un mundo continuo que llena el encuadre de borde a borde, con la zona tranquila integrada en ese mismo mundo: sombra suave, profundidad que se aleja o una superficie lisa. Si pides "oscuridad vacía y generosa a izquierda y derecha", el modelo puede crear paneles negros literales en los lados y obligarte a repetir. La descripción de borde a borde suele funcionar al primer intento.

La misma trampa tiene una variante de simetría. Cuando la composición necesite un sujeto centrado, decir "centrado" no basta. Indica que el sujeto divide el encuadre exactamente por la mitad, a la misma distancia de los bordes izquierdo y derecho. Describe ambos lados con el mismo tratamiento y prohíbe expresamente objetos, piezas mecánicas y brillos intensos en los laterales. En un proyecto real hicieron falta tres intentos para conseguir la toma hasta usar esta redacción.

Si el usuario proporcionó una fotografía real del producto, esa imagen puede ser el fotograma inicial. Primero revisa su resolución y composición, y confirma que el espacio negativo funciona para el diseño.

Cuando el sujeto sea una persona real, como el dueño, chef o fabricante, su foto se usa como imagen de referencia y no como fotograma inicial. Genera el fotograma inicial con un modelo que acepte referencias de personaje, vuelve a describir sus rasgos reconocibles en el prompt, como cabello, lentes y ropa, y revisa el parecido del mismo modo que revisarías una marca registrada. El parecido forma parte de la coherencia de marca. Un rostro apenas diferente hace fallar todo el sitio. Antes de generar cualquier rostro hay una regla estricta: utiliza únicamente una foto del propio usuario o de una persona que haya aceptado aparecer en el sitio. Si la fotografía pertenece a alguien más, detente y pregunta antes de generar.

### Plantilla de video (imagen a video, 1080p, 6 segundos, modo estándar, sin audio; alrededor de 54 créditos en el modelo más caro y mucho menos en uno de precio medio)

```
Una sola toma continua, sin cortes. [SUJETO] [VERBO DEL RECORRIDO: se vierte,
desciende, se acerca, se ensambla] desde [ESTADO INICIAL] hasta [ESTADO FINAL]
a lo largo de [TRAYECTORIA EXPLÍCITA: directamente hacia abajo por el centro
del encuadre, un avance lento, etc.]. El [SUJETO] permanece vivo durante toda
la toma: [MOVIMIENTO NATURAL PEQUEÑO: ondulación, balanceo, microajustes]. La
escena permanece viva: [VIDA AMBIENTAL: vapor flotando, luz cambiante, nubes
en movimiento]. [SI CRUZA UNA SUPERFICIE: el momento físico sobre el lente,
por ejemplo una salpicadura y gotas en el lente con un instante de desenfoque].
La toma termina en reposo: [FOTOGRAMA FINAL BIEN COMPUESTO Y DESCRITO POR
COMPLETO: qué aparece, dónde está, qué hace la luz y por qué se siente como una
llegada]. Sin texto ni letras en ninguna parte.
```

Genera en 1080p, no en 4K. La versión web se recodificará y comprimirá de todas formas. Usar 4K solo multiplica el costo.

## Receta para encadenar (Nivel 2: recorrido de 15 a 20 segundos)

Un recorrido largo se construye con segmentos de 6 segundos unidos de forma imperceptible:

1. Genera el segmento 1 a partir del fotograma inicial. Haz la inspección completa y solicita la ⛔ APROBACIÓN DEL VIDEO únicamente para ese segmento.
2. Extrae con ffmpeg el último fotograma del segmento aprobado como PNG de calidad completa. El comando exacto está en `recetas-ffmpeg.md`. Los JPG de revisión no tienen calidad suficiente para encadenar.
3. Sube ese PNG a Higgsfield. Este es el puente entre el archivo local y un `start_image`, y tiene tres pasos: llama a `media_upload`, que devuelve una URL PUT prefirmada, es decir, una dirección temporal de carga. Después envía los bytes del PNG a esa URL, por ejemplo con `curl -X PUT --upload-file final.png "<presigned-url>"`. Finalmente llama a `media_confirm` para registrar la carga. El identificador confirmado es el valor que se pasa como `start_image` al siguiente llamado de imagen a video.
4. Escribe el prompt del siguiente segmento para que el movimiento CONTINÚE: misma dirección, misma velocidad, misma iluminación y exactamente desde el punto donde terminó el segmento anterior. La unión solo desaparece si el vector de movimiento no se interrumpe. Un caso especial frecuente ocurre cuando un segmento termina casi vacío o negro, por ejemplo con un solo punto de luz. El prompt del siguiente segmento debe describir de manera explícita qué crece a partir de ese fotograma. Así desaparece la unión.
5. Aprueba cada segmento por separado. Si uno se rechaza, solo se repite ese segmento, no todo el recorrido.
6. Une los segmentos aprobados en un solo archivo mediante la concatenación con una única codificación de `recetas-ffmpeg.md`. Alimenta los segmentos ORIGINALES a un solo filtro y codifica una vez con los ajustes de desplazamiento. Una sola codificación evita diferencias entre uniones. Si ya no existen los originales, codifica todos los segmentos con parámetros IDÉNTICOS y únelos con el demultiplexor concat. Los parámetros idénticos mantienen invisibles las uniones. Si difieren, cada unión puede fallar.
7. El archivo unido es el único video que utiliza la página. El sitio nunca necesita saber que se generó en segmentos.

Solo el último segmento necesita el final compuesto y en reposo de la ley 4. Los segmentos intermedios deben terminar en movimiento para que el siguiente pueda continuarlos.

**La ley de las uniones: la identidad de la textura no se conserva.** Cada generación vuelve a interpretar los detalles finos a partir de su fotograma inicial. La posición se conserva, pero el tejido, grano o piel exactos no. Por eso una unión entre dos estados inmóviles con una textura muy específica se percibe como un corte aunque el vector de movimiento sea perfecto. Planea cada unión dentro del movimiento o dentro de un instante que justifique refrescar la textura: un barrido sobre el lente, un desenfoque, un momento oscuro o un cambio de luz. Nunca juntes directamente dos estados en reposo con una textura específica. Si la cadena ya está generada y la unión sigue visible, utiliza el fundido cruzado de `recetas-ffmpeg.md`.

**Mundos que se encadenan con fiabilidad.** Los mundos abstractos, hechos de luz, partículas y atmósfera, son los más confiables. Como no tienen anatomía que el prompt de continuación pueda interpretar mal, una cadena de tres segmentos puede funcionar al primer intento. Cuando haya dudas entre dos conceptos de Nivel 2, esta es una razón importante para elegir el abstracto.

## Rechazar presets

En ocasiones, el generador relaciona el prompt con un estilo predeterminado y lo ofrece en lugar de crear la toma. Recházalo y vuelve a intentar con el prompt literal. La toma diseñada sigue estas leyes y está compuesta para el sitio. Un preset no.

## Consulta previa de costos

Antes de CUALQUIER generación, consulta el precio exacto de la llamada planeada con `get_cost: true`. Es gratis. Explica cada costo con palabras sencillas antes de gastar: primero el precio del fotograma inicial, por ejemplo "La imagen inicial cuesta alrededor de 2 créditos. La generaré ahora". Cuando la imagen haya sido aprobada, presenta el menú de modelos con precios reales antes de gastar créditos de video. Primero el paso económico, después la decisión grande y siempre con cifras reales.

**El modelo de video es una decisión real y corresponde al usuario.** El conector ofrece varios modelos. Con los mismos parámetros, como duración, resolución y modo, se ha medido una diferencia cercana a cinco veces entre el modelo más caro y uno de precio medio. Al momento de escribir esto, ambos extremos ofrecen nivel profesional: las clasificaciones independientes colocan la opción recomendada entre las mejores por calidad general y fidelidad al prompt, y la alternativa intermedia entre las mejores por física y movimiento cinematográfico. Consulta la MISMA toma en los dos o tres modelos principales. Descubre la lista vigente mediante el catálogo del conector. `get_cost` es gratuito para todos. Después presenta las cifras reales y el intercambio honesto: la opción recomendada es aquella para la que se ajustaron estas reglas y ofrece el techo de calidad más alto. El modelo de precio medio también es una opción legítima y convierte un saldo pequeño o de prueba, de una sola toma a muchas, lo cual vuelve la aprobación del video una decisión creativa normal y no un riesgo intimidante. Es el dinero del usuario y la decisión se toma antes de gastar.

Con la configuración recomendada, una imagen principal cuesta alrededor de 2 créditos y el video aproximadamente 54, que representa la parte alta del rango. Una prueba gratuita suele cubrir un recorrido principal y un intento adicional, o más si se utiliza un modelo económico. Para un recorrido encadenado, consulta el costo de toda la cadena y presenta por adelantado el total por segmento.
