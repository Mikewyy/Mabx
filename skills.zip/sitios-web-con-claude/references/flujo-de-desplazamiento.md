# Flujo de desplazamiento y estándar de ingeniería

Este es el estándar comprobado para una portada cuyo video responde al desplazamiento y para el nivel mínimo de calidad que la rodea. Utilízalo completo en todos los proyectos. Cada regla produjo un detalle de calidad o evitó un error que llegó a publicarse y después fue detectado.

## Estructura de la portada

La portada es una sección alta y fija que contiene un escenario adhesivo del tamaño completo de la ventana. El progreso dentro de la región fija va de 0 a 1 y controla el tiempo del video. La página llega a su punto de reposo exactamente cuando el video alcanza el final compuesto, y ahí comienza el resto del sitio.

**Mide la portada en distancia de desplazamiento, usando `vh`, no en segundos.** Una toma única de 6 segundos de Nivel 1 necesita alrededor de `400vh`. Un recorrido encadenado de 18 segundos necesita cerca de `1000vh` para dar espacio a cada momento. Si un recorrido largo tiene poca altura, todos los textos pasarán demasiado rápido aunque las bandas estén bien ajustadas. Los valores de ritmo están en la sección de bandas de texto.

## Cargar el video como Blob (la regla de HTTP Range)

Muchos servicios de hosting no admiten descargas parciales mediante HTTP Range. Sin ese soporte, cada búsqueda del video vuelve a cero y el desplazamiento no funciona en el sitio publicado, aunque localmente parezca perfecto. Descarga el archivo completo como Blob, es decir, conserva el video en memoria, y reproduce su URL de objeto. Este método funciona en cualquier servidor.

Para un clip pequeño, de menos de 8 MB aproximadamente, la forma sencilla es suficiente:

```js
const res = await fetch('assets/hero-scrub.mp4');
const blob = await res.blob();
video.src = URL.createObjectURL(blob);
```

Asigna la imagen previa desde JavaScript al mismo tiempo y dentro de la misma ruta que decide si debe cargar el video. Así los teléfonos y las personas con movimiento reducido, que reciben la portada estática, no descargan ninguno de los dos archivos.

### Blob transmitido con indicador de carga (para videos de más de 8 MB)

Usar directamente `await fetch().blob()` con un video encadenado grande congela silenciosamente la primera impresión. No ocurre nada visible hasta que termina de descargarse el archivo. Por encima de 8 MB, transmítelo por partes. La página se puede usar desde el primer momento, la imagen previa aparece primero, un indicador muestra el progreso real mientras llega el Blob y el sitio sigue completo si el video nunca termina de cargar.

El elemento de video se entrega con `preload="none"` y sin `src`. El indicador es un círculo SVG de radio 20, con una circunferencia aproximada de 126, controlado por una variable CSS:

```html
<video id="hero" preload="none" muted playsinline aria-hidden="true" tabindex="-1"></video>
<svg class="ring" viewBox="0 0 48 48" aria-hidden="true">
  <circle cx="24" cy="24" r="20" fill="none" stroke="currentColor" stroke-width="3"
          stroke-dasharray="126" style="stroke-dashoffset:var(--ld,126)"/>
</svg>
```

```js
const VIDEO_URL = 'assets/hero-scrub.mp4';
const VIDEO_BYTES = 14476000;   // tamaño real en bytes; respaldo cuando falta Content-Length
const ring = document.querySelector('.ring');
const posterLayer = document.querySelector('.poster');

// 1. La imagen previa gana intencionalmente la prioridad de descarga: muéstrala
//    primero y comienza a cargar el Blob cuando la imagen aparezca o falle.
posterLayer.style.backgroundImage = "url('assets/hero-poster.jpg')";
let started = false;
function startBlobFetch() {
  if (started) return;
  started = true;
  loadHeroBlob().catch(failVideo);
}
const posterImg = new Image();
posterImg.onload = startBlobFetch;
posterImg.onerror = startBlobFetch;
posterImg.src = 'assets/hero-poster.jpg';
setTimeout(startBlobFetch, 4000);   // seguridad: una imagen detenida no bloquea el video para siempre

async function loadHeroBlob() {
  const ctrl = new AbortController();
  let watchdog = setTimeout(() => ctrl.abort(), 20000);
  // priority:'low' hace que el Blob ceda prioridad a los recursos esenciales
  const res = await fetch(VIDEO_URL, { priority: 'low', signal: ctrl.signal });
  const total = Number(res.headers.get('Content-Length')) || VIDEO_BYTES;
  const reader = res.body.getReader();
  const chunks = [];
  let got = 0, lastRing = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    clearTimeout(watchdog);                             // reinicia con cada fragmento:
    watchdog = setTimeout(() => ctrl.abort(), 20000);  // 20 s sin progreso cancelan la transmisión
    chunks.push(value);
    got += value.length;
    const frac = Math.min(1, got / total);
    const now = performance.now();
    if (now - lastRing > 100 || frac === 1) {          // limita a 100 ms, pero garantiza
      lastRing = now;                                  // la escritura final para completar el círculo
      ring.style.setProperty('--ld', Math.round(126 * (1 - frac)));
    }
  }
  clearTimeout(watchdog);
  ring.style.setProperty('--ld', 0);
  video.src = URL.createObjectURL(new Blob(chunks));
  video.load();
  video.addEventListener('canplay', () => {
    requestSeek(heroProgress() * video.duration);  // abre en la posición actual del desplazamiento
    stage.classList.add('video-ready');            // CSS desvanece el video sobre la imagen previa
  }, { once: true });
}

function failVideo() {
  ring.replaceWith(makeScrollChevron());  // señal honesta para bajar, nunca un indicador detenido
  stage.classList.add('video-failed');    // las imágenes estáticas sostienen el recorrido completo
}
```

El temporizador de vigilancia es importante. Sin él, una transmisión detenida congela el indicador para siempre, lo cual es peor que no mostrarlo. Con este control, 20 segundos sin avance cancelan la descarga, activan la portada estática y el sitio continúa funcionando.

Este patrón permite que incluso un recorrido encadenado de varios megabytes se descargue discretamente detrás del indicador durante algunos segundos, mientras la página puede utilizarse casi de inmediato.

## Interpolar el tiempo mostrado (un ciclo rAF que descansa)

Nunca escribas directamente la posición del desplazamiento en `currentTime`. Acércate a ella con suavidad. El ciclo debe detenerse cuando converge y cuando la portada sale de pantalla. Un ciclo que continúa desde que carga la página gasta batería y hace que el proyecto parezca poco profesional.

```js
let target = 0;      // 0..1, definido por el controlador de desplazamiento
let shown = 0;       // valor que se muestra
let rafId = null;
let lastTick = 0;

function tick(now) {
  const dt = Math.min(100, now - (lastTick || now));   // ms desde el último cuadro, con límite
  lastTick = now;
  const k = 0.16;    // suavizado por cuadro a 60 fps; punto inicial que se ajusta al probar
  shown += (target - shown) * (1 - Math.pow(1 - k, dt / 16.667));
  if (Math.abs(target - shown) < 0.0005) {
    shown = target;
    rafId = null;
    lastTick = 0;                     // convergió: descansar
  } else {
    rafId = requestAnimationFrame(tick);
  }
  requestSeek(shown * video.duration);
  updateCaptions(shown);
}

function onScroll() {
  target = heroProgress();            // 0..1 dentro de la portada fija
  if (rafId === null && heroOnScreen) rafId = requestAnimationFrame(tick);
}
```

La línea con `Math.pow` hace que la sensación sea independiente de la velocidad de actualización. El exponente normaliza el suavizado respecto a 60 fps, por lo que todas las pantallas convergen a la misma velocidad. Una constante aplicada por fotograma, como `shown += (target - shown) * 0.18`, converge dos veces más rápido a 120 Hz que a 60 Hz y hace que el sitio se sienta distinto en cada equipo.

Controla `heroOnScreen` con IntersectionObserver para que el ciclo no se ejecute cuando la portada ya no esté visible.

## Bloquear búsquedas superpuestas (patrón seguro contra bloqueos)

Nunca escribas en `currentTime` mientras una búsqueda anterior siga en proceso. Las búsquedas sin control se acumulan y marcan la diferencia entre un desplazamiento fluido y uno entrecortado en Chrome. Conserva solo el destino más reciente, ejecuta exactamente una búsqueda adicional cuando termine la anterior y restablece la bandera si hay un error para evitar un bloqueo permanente:

```js
let seekBusy = false;
let pendingTime = null;

function requestSeek(t) {
  if (!video.duration) return;
  if (seekBusy) { pendingTime = t; return; }   // combina: conserva solo el valor más reciente
  seekBusy = true;
  video.currentTime = t;
}

video.addEventListener('seeked', () => {
  seekBusy = false;
  if (pendingTime !== null) {
    const t = pendingTime;
    pendingTime = null;
    requestSeek(t);                            // exactamente una búsqueda adicional
  }
});

video.addEventListener('error', () => {        // salida del bloqueo
  seekBusy = false;
  pendingTime = null;
});
```

Bajo carga, este patrón produce una finalización por búsqueda y ninguna superposición. Si todavía se siente áspero, el intervalo de fotogramas clave es demasiado largo. Vuelve a codificar con `-g 8`, según `recetas-ffmpeg.md`.

## Escribir en el DOM solo cuando hay cambios

Las escrituras en el DOM en cada fotograma son la otra causa principal de interrupciones. Controla todas las diferencias:

- Para textos, veladuras y clases de estado, calcula el valor deseado, compáralo con un valor guardado y toca el DOM solo si cambia. Nunca actives y desactives una clase en cada fotograma.
- Para cualquier texto que cambia con el desplazamiento, como contadores, indicadores de profundidad o progreso, limita las actualizaciones a unos 10 Hz Y escribe solo cuando cambie la cadena.

```js
let lastLabel = '';
let lastLabelAt = 0;

function updateLabel(text, now) {
  if (now - lastLabelAt < 100) return;   // aproximadamente 10 Hz
  if (text === lastLabel) return;        // solo cuando cambia
  lastLabel = text;
  lastLabelAt = now;
  labelEl.textContent = text;
}
```

Promueve el video a su propia capa de composición, usando `will-change: transform` o `transform: translateZ(0)` en el elemento, para que sus repintados no arrastren al resto de la página.

## Patrón de bandas de texto (ritmo medido en distancia de desplazamiento)

Cada texto ocupa una banda de progreso, por ejemplo `[0.12, 0.30]`. Los textos se colocan en el espacio negativo del video, planeado desde la fase de concepto, y el carril de acción permanece libre. Nada debe aparecer de golpe.

Mide cada banda en `vh`, es decir, alturas de la ventana, y nunca en segundos, porque el sitio se lee con movimientos de desplazamiento. El estándar es:

- **Cada momento debe tener una meseta totalmente visible de aproximadamente 80 a 130vh**, con transiciones suaves cercanas a 20vh en cada extremo. Son puntos de partida que se validan con la prueba descrita más abajo. La meseta ocupa casi toda la banda y las transiciones son breves.
- **Calcula las transiciones en unidades de progreso.** Para una banda `[a, b]`: `const f = Math.min(0.02, (b - a) / 3)`. En un recorrido de `900vh`, donde la distancia es la altura de la portada menos la ventana de `100vh`, un progreso de `0.02` equivale a `18vh`.
- **La opacidad** utiliza `smoothstep` en ambos extremos:

```js
const smoothstep = (p, e0, e1) => {
  const t = Math.min(1, Math.max(0, (p - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
};
const f = Math.min(0.02, (b - a) / 3);
const opacity = smoothstep(p, a, a + f) * (1 - smoothstep(p, b - f, b));
```

La primera banda omite la aparición gradual y la última omite la desaparición, para que el recorrido comience y termine con el texto ya colocado.

- **El progreso de armado del texto**, representado por la variable `--k` utilizada en la coreografía, se estabiliza aproximadamente `20vh` después de comenzar la banda. Así deja una meseta larga y completamente asentada:

```js
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const k = clamp((p - a) / (ramp || Math.min(0.025, (b - a) * 0.35)), 0, 1);
```

`ramp` es el valor opcional `data-ramp` de la banda, explicado en la sección de coreografía. Aplica todos los cambios únicamente cuando difieran del valor anterior, como con cualquier escritura en el DOM controlada por desplazamiento.

**Prueba de desplazamiento para validar el mapa:** simula pasos de rueda de 120 píxeles, que representan un movimiento normal; 240 píxeles; y 360 píxeles, equivalentes a un movimiento doble y agresivo. Cada texto debe permanecer legible durante 5 o 6 movimientos normales y ninguno puede saltarse incluso con pasos de 360 píxeles. Arrastrar lentamente no demuestra nada. Los visitantes reales se desplazan por impulsos. Si un texto falla, combínalo con el vecino. Nunca reduzcas las transiciones para intentar hacerlo caber.

La prueba es un ciclo pequeño que se ejecuta en la página mediante la herramienta de navegador o se pega en la consola. Haz una ejecución por cada tamaño de paso:

```js
// flick(120, 12), después flick(240, 8) y flick(360, 6). Empieza arriba en cada ejecución.
async function flick(step, count) {
  for (let i = 0; i < count; i++) {
    window.scrollBy(0, step);
    await new Promise(r => setTimeout(r, 400));   // una pausa entre movimientos, como un lector real
    const bands = [...document.querySelectorAll('.band')]
      .map((b, n) => n + ':' + getComputedStyle(b).opacity);
    console.log('y=' + Math.round(scrollY), bands.join('  '));
  }
}
```

Lee las opacidades registradas entre cada paso. Una banda que nunca alcanza opacidad completa durante la prueba de 360 píxeles puede saltarse. Una que permanece totalmente visible durante menos de 5 pasos consecutivos de 120 píxeles es demasiado breve para leer.

## Sistema de legibilidad (texto sobre video en movimiento)

La ley 10 de `leyes-de-prompts.md` señala que un video detrás del texto es un fondo cambiante que no se controla fotograma por fotograma. Cada banda de la portada utiliza las cuatro capas siguientes y después debe superar la auditoría.

**1. Veladura general.** Coloca sobre todo el video un oscurecimiento radial suave y permanente. Así nunca hay un fotograma completamente descubierto detrás de la página:

```css
.scrim{position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse 120% 90% at 50% 45%,rgba(10,10,18,0) 35%,rgba(10,10,18,.62) 100%)}
```

**2. Veladura por banda.** El pseudo-elemento `::before` de cada banda contiene una veladura radial que sigue la opacidad controlada por JavaScript y se intensifica con la variable `--k`. De esta forma el video se oscurece solo mientras el texto está visible. Oscurece, pero no aplana. El degradado desaparece al 76 por ciento para que las esquinas conserven vida. Esta es la forma recomendada:

```css
.band::before{content:"";position:absolute;inset:-4%;pointer-events:none;opacity:calc(.25 + .75*var(--k,1));background:radial-gradient(ellipse 74% 62% at 50% 50%,rgba(5,5,10,.66) 0%,rgba(5,5,10,.44) 46%,rgba(5,5,10,0) 76%)}
```

Ajusta la opacidad máxima de cada banda usando sus fotogramas reales. El rango comprobado va desde `0.62` para momentos tranquilos hasta `0.72` para el gancho. Esos valores también son los que debes modificar cuando el usuario pida que el video se vea más brillante.

**Variante doble para composiciones con acción centrada.** La veladura radial única anterior supone que el sujeto está fuera del centro y los textos lo rodean. Cuando el sujeto se encuentre en el centro y haya columnas de texto a AMBOS lados, nunca estires una sola veladura sobre el centro. Usa dos: un pseudo-elemento anclado en la columna izquierda y otro en la derecha, cada uno con una elipse centrada sobre su columna. Mantén completamente despejado el carril central para que el sujeto conserve brillo. La banda final, donde convergen las columnas, utiliza una sola elipse centrada en la parte superior. Esta variante no sacrifica calidad. En un proyecto real alcanzó un contraste de 7.17 a 1 en el peor píxel.

**3. Variable de sombra del texto.** Usa tres capas, una arista cerrada, un brillo intermedio y una caída amplia. Aplícala a todas las bandas, pero desactívala en los botones, donde una etiqueta con sombra parece sucia:

```css
:root{--tshadow:0 1px 2px rgba(5,5,10,.95),0 3px 12px rgba(5,5,10,.78),0 10px 44px rgba(5,5,10,.8)}
.band{text-shadow:var(--tshadow)}
.band .btn{text-shadow:none}
```

**4. Fondo compacto para texto pequeño.** Las líneas HUD, lecturas y etiquetas pequeñas sobre el video no utilizan el radial grande. Llevan una cápsula pequeña y desenfocada como respaldo:

```css
.chip{background:rgba(8,8,15,.55);border:1px solid rgba(96,96,126,.3);border-radius:10px;backdrop-filter:blur(10px);text-shadow:0 1px 3px rgba(5,5,10,.85)}
```

**Auditoría del peor fotograma.** Extrae los fotogramas de cada banda, combina la veladura mediante Canvas sobre la zona del texto y exige un contraste mínimo de 3.5:1 en el peor píxel. Una banda bien ajustada normalmente supera con claridad ese límite. Ajusta las opacidades contra el peor fotograma y nunca contra el promedio. El promedio engaña. El peor fotograma puede aparecer justo mientras el visitante está leyendo.

**Método recomendado cuando se puede controlar un navegador**, por ejemplo mediante Chrome headless según `solucion-de-problemas.md`: inyecta `visibility: hidden` en los fragmentos de texto, captura la página ya compuesta en la posición correspondiente y localiza el píxel más claro dentro del rectángulo del texto. Esto mide exactamente todas las veladuras y su caída radial tal como las ve el visitante. También es conservador porque, al ocultar las letras, desaparece su sombra. El procedimiento de fotogramas y cálculo siguiente es la alternativa cuando no se puede controlar un navegador.

Procedimiento concreto:

1. Convierte el rango de cada banda a tiempo del video con `time = progress * duration` y extrae tres o cuatro fotogramas con ffmpeg: `ffmpeg -ss <t> -i assets/hero-scrub.mp4 -frames:v 1 review/band2-a.png`.
2. Para cada fotograma, combina la veladura de la banda con su opacidad máxima sobre la zona del texto y encuentra el peor píxel. Con texto claro, es el píxel superviviente más claro. Este código realiza el paso completo:

```js
// auditFrame('audit/band2-a.png', {x:420,y:300,w:600,h:200}, 0.66, [244,242,236])
// zone es el rectángulo del texto, alpha es el máximo de la veladura y textColor es RGB
async function auditFrame(src, zone, scrimAlpha, textColor) {
  const img = await createImageBitmap(await (await fetch(src)).blob());
  const c = new OffscreenCanvas(img.width, img.height).getContext('2d');
  c.drawImage(img, 0, 0);
  const d = c.getImageData(zone.x, zone.y, zone.w, zone.h).data;
  const lum = ([r, g, b]) => {
    const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  };
  const scrim = [5, 5, 10];                      // color base de la veladura
  let worst = 0;
  for (let i = 0; i < d.length; i += 4) {
    const px = [0, 1, 2].map(j => d[i + j] * (1 - scrimAlpha) + scrim[j] * scrimAlpha);
    worst = Math.max(worst, lum(px));             // píxel más claro, el peor caso para texto claro
  }
  const lt = lum(textColor);
  const hi = Math.max(lt, worst), lo = Math.min(lt, worst);
  return (hi + 0.05) / (lo + 0.05);              // debe ser por lo menos 3.5
}
```

Ejecútalo con la herramienta de navegador sobre la página en vista previa. Si no se permite cargar archivos desde `review/`, copia temporalmente los fotogramas a `assets/audit/` y elimina esa carpeta antes de crear el ZIP.

3. El resultado de cada banda debe ser por lo menos 3.5:1. Si una no pasa, aumenta la opacidad máxima de su veladura y repite la auditoría con el mismo peor fotograma.

## Coreografía del texto (una personalidad de entrada por momento)

**Principio de eco:** cada momento de la portada tiene una entrada propia que refleja la acción del video. Las palabras descienden mientras algo cae. Una palabra golpea al aparecer cuando ocurre un impacto. Los caracteres se dispersan y se unen mientras la tinta se reúne. La entrada y el video deben sentirse como un solo acontecimiento. Eso hace que la página parezca dirigida y no simplemente decorada.

La ingeniería es fija para todas las entradas, incluidas las inventadas: los efectos usan únicamente `transform` y `opacity`; responden al desplazamiento mediante la propiedad `--k` de la banda, de 0 a 1; el ciclo controlador escribe esa propiedad solo cuando la diferencia supera `0.008`, para que una banda estable no consuma recursos; y todos los efectos son reversibles al subir. La única excepción diseñada es la animación inicial de la primera banda.

**La primera banda se abre ya estable, incluidos los caracteres.** El patrón anterior omite la transición de opacidad de la primera banda, pero eso no basta. Al inicio, `--k` todavía vale 0, por lo que los caracteres siguen desarmados y la portada muestra video sin palabras hasta que el usuario se desplaza. Da a la primera banda una animación de armado basada en tiempo que se ejecute una sola vez al cargar y luego entregue el control al desplazamiento: usa `k = max(scrollK, loadK)`, donde `loadK` sube suavemente de 0 a 1 durante los primeros instantes. Cuando llega a 1, la función mantiene armada la primera banda, que es correcto porque no existe contenido anterior al cual regresar. Todas las bandas posteriores continúan totalmente controladas por desplazamiento y son reversibles.

**Dividir una sola vez al cargar.** Separa el título en palabras y caracteres desde JavaScript mediante un generador pseudoaleatorio con semilla, para que los valores supuestamente aleatorios sean idénticos en cada carga:

```js
function rng(seed) {
  let s = seed >>> 0;
  return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296;
}
```

Incluye un `span` oculto visualmente con la frase completa para lectores de pantalla y, además, una copia visual con `aria-hidden="true"`, construida con elementos `.w` para palabras que contienen elementos `.c` para caracteres. Al dividir, asigna a cada fragmento sus propiedades personalizadas `--th`, `--jx`, `--jy` y `--jr` mediante el generador con semilla.

**Menú de ejemplos, cada uno nombrado según el momento del video que refleja:**

**(a) Dispersión.** Cada carácter llega desde una posición pseudoaleatoria. Refleja tinta que se reúne, partículas que se ensamblan o restos que se asientan. Cada `.c` recibe `--th`, un umbral aleatorio de 0 a 0.55, además de desplazamientos `--jx`, `--jy` y giro `--jr`:

```css
.c{--kc:clamp(0,(var(--k,0) - var(--th,0))*2.6,1);opacity:var(--kc);
   transform:translate(calc((1 - var(--kc))*var(--jx,0px)),calc((1 - var(--kc))*var(--jy,0px)))
             rotate(calc((1 - var(--kc))*var(--jr,0deg)))}
```

**(b) Alineación en cuadrícula.** Los caracteres se deslizan horizontalmente hasta su lugar siguiendo el orden de lectura. Utiliza el mismo CSS de dispersión con movimiento solo horizontal, pero ordena el umbral en lugar de hacerlo aleatorio: `--th: charIndex / total * spread + rng() * 0.06`. El valor `spread` controla cuánto dura el escalonamiento.

**(c) De desenfocado a nítido.** Es la entrada para un momento tranquilo y refleja la niebla que se disipa o el enfoque que llega. Utiliza dos copias superpuestas del texto y cruza sus opacidades. La copia suave lleva un `filter: blur(10px)` ESTÁTICO. Nunca animes directamente `filter`, porque no es eficiente para la capa de composición. La copia nítida aparece con `--k` mientras la suave desaparece.

**(d) Golpe de palabras con rebote.** Refleja un impacto. Usa una aparición por palabra mediante `--kc` y un asentamiento más lento mediante `--ks`. La palabra supera la escala 1 y luego regresa:

```css
.w{--kc:clamp(0,(var(--k,0) - var(--th,0))*3,1);
   --ks:clamp(0,(var(--k,0) - var(--th,0) - var(--sd,.1))*var(--ss,3.2),1);
   opacity:var(--kc);
   transform:scale(calc(0.6 + (0.4 + var(--ov,.12))*var(--kc) - var(--ov,.12)*var(--ks)))}
.w.em{--ov:0.24;--sd:0.16;--ss:2.6}
```

Las palabras destacadas con `.em` reciben un rebote mayor y se estabilizan más tarde y más despacio, para permanecer un instante adicional fuera de escala.

**(e) Ascenso palabra por palabra hacia un cierre escalonado.** Es la entrada recomendada para el final y coincide con la llegada del video al reposo. Las palabras del título suben en orden de lectura mediante `--th`. Después aparece el subtítulo con `--ks: clamp(0, (var(--k) - 0.66) * 4, 1)` y finalmente la fila de llamada a la acción con `--kb: clamp(0, (var(--k) - 0.78) * 5, 1)`. Son tres llegadas dentro de una banda.

**(f) Descenso flotante.** Refleja una caída o un líquido que se vierte. Cada palabra comienza por encima de su posición final y baja suavemente:

```css
.w{--kc:clamp(0,(var(--k,0) - var(--th,0))*2.8,1);opacity:var(--kc);
   transform:translateY(calc((1 - var(--kc))*-24px))}
```

**(g) Acercamiento desde la profundidad.** Refleja un túnel o el avance de la cámara. La línea comienza ligeramente pequeña y crece como si se acercara: `transform: scale(calc(0.82 + 0.18 * var(--kc)))`, con la opacidad controlada por `--kc`. Cuando también deba ganar nitidez, añade debajo una copia suave con desenfoque estático, siguiendo el patrón anterior.

**(h) Mitades que se abren.** Refleja pliegues o cortinas que se separan. Divide el título en dos mitades. Cada una comienza atraída hacia la línea central y se desliza hacia afuera mientras sube `--kc`, con signos opuestos de `--jx`.

**(i) Tejido.** Refleja hilos que se cruzan o hebras que se entrelazan. Los caracteres llegan alternando desde arriba y abajo. Utiliza el CSS de dispersión con movimiento vertical y alterna el signo de `--jy` según el índice de cada carácter.

**Este menú contiene ejemplos, no una lista cerrada.** Parte del trabajo es inventar una entrada que corresponda al video. Observa qué hace físicamente la imagen durante la banda y aplica el mismo principio a las palabras. Cada efecto inventado conserva la base fija: únicamente `transform` y `opacity`, controlados por `--k` y reversibles al subir. La animación inicial y única de la primera banda sigue siendo la única excepción.

**Patrón de control para ajustar un momento sin cambiar las matemáticas de la banda.** Cada banda admite dos atributos HTML opcionales. `data-ramp` reemplaza la ventana de armado predeterminada, cuyo valor es `Math.min(0.025, bandLength * 0.35)` del progreso. Por ejemplo, `data-ramp="0.036"` alarga el armado cerca de 50 por ciento. `data-spread` controla el escalonamiento de caracteres para las entradas de dispersión y cuadrícula. Así cada momento se ajusta desde su marcado y el ciclo controlador permanece intacto.

## Condición para la portada estática (cinco casos en CSS Y JavaScript)

Algunos visitantes reciben una portada compuesta con una imagen fija en lugar del video controlado por desplazamiento. Hay cinco condiciones, y deben coincidir EXACTAMENTE entre las consultas de CSS y la decisión de JavaScript. Si difieren, una parte puede descargar recursos que la otra oculta:

1. Teléfonos: `(max-width: 720px)`
2. Tabletas verticales: `(orientation: portrait) and (max-width: 1024px)`
3. Puntero impreciso en vertical: `(orientation: portrait) and (pointer: coarse)`
4. Teléfonos horizontales: `(orientation: landscape) and (pointer: coarse) and (max-height: 560px)`. Un teléfono girado puede superar todas las pruebas de ancho, pero no tiene altura suficiente para el recorrido.
5. Movimiento reducido: `(prefers-reduced-motion: reduce)`

**La condición se decide en vivo, no una sola vez al cargar.** Las consultas CSS se vuelven a evaluar al girar el dispositivo, cambiar el tamaño de la ventana o modificar preferencias. Una comprobación única de JavaScript deja una portada vacía de varias pantallas cuando una tableta cambia de vertical a horizontal, una ventana supera 720 píxeles o se desactiva el movimiento reducido durante la sesión. CSS muestra el escenario animado, pero JavaScript nunca creó la imagen, el video ni el detector de desplazamiento. Conecta el evento `change` de las cinco consultas a una función que active o desactive el recorrido:

```js
const GATES = [
  '(max-width: 720px)',
  '(orientation: portrait) and (max-width: 1024px)',
  '(orientation: portrait) and (pointer: coarse)',
  '(orientation: landscape) and (pointer: coarse) and (max-height: 560px)',
  '(prefers-reduced-motion: reduce)'
];
let scrubOn = false;
function enableScrub(){
  if (scrubOn) return; scrubOn = true;
  initHeroOnce();                       // reúne la imagen previa y startBlobFetch en una función de ejecución única
  addEventListener('scroll', onScroll, {passive:true});
  bands.forEach(b => { b.op = -1; b.k = -1 });   // reinicia cachés para reescribir estilos antiguos
  unpinFinalStates();                   // revierte los estados fijos y devuelve el control al desplazamiento
  updateCaptions(heroProgress());
  onScroll();                           // busca la posición actual; sin esto el fotograma queda atrasado
}
function disableScrub(){
  if (!scrubOn) return; scrubOn = false;
  removeEventListener('scroll', onScroll);
  if (rafId !== null) { cancelAnimationFrame(rafId); rafId = null }
}
function applyHeroMode(){
  if (GATES.some(q => matchMedia(q).matches)) disableScrub();
  else enableScrub();
}
const MQLS = GATES.map(q => matchMedia(q));   // conserva referencias; navegadores antiguos pueden perder detectores sin ellas
MQLS.forEach(m => m.addEventListener('change', applyHeroMode));
applyHeroMode();
```

Las cinco cadenas deben coincidir carácter por carácter en ambos lugares. La imagen previa y la descarga del Blob deben vivir ÚNICAMENTE dentro de esta ruta condicionada.

Hay una protección relacionada para pantallas capaces de mostrar el recorrido pero con poca altura, como una ventana de escritorio baja. Conserva el video, pero oculta las superposiciones pequeñas controladas por desplazamiento, como señales, lecturas o indicadores, porque no tienen espacio. Este ejemplo utiliza nombres de clase de un proyecto. Sustitúyelos por los tuyos:

```css
@media (max-height:560px){.cue,.hud,.feed{display:none}}
```

La portada estática es un diseño intencional, no una disculpa. Compón la imagen inicial o final con los textos visibles. La decisión móvil se toma de forma consciente en cada proyecto. La opción predeterminada es la portada estática. Considera un video móvil recortado con `cover` solo cuando se cumplan las tres condiciones: el video codificado pesa menos de 8 MB aproximadamente, la composición sigue funcionando al recortarse en formato vertical y el carril de acción sobrevive, y el resultado fue comprobado en un teléfono real. Si falla cualquiera, publica con orgullo la portada fija.

## El sitio debe estar completo sin video

La página debe verse completa y atractiva aunque el video nunca cargue. Conecta el evento `error` para ocultar el elemento de video fallido sobre el fondo de imagen. Cada texto, sección y llamada a la acción debe funcionar con una imagen fija. Prueba este estado deliberadamente cambiando el nombre del archivo de video y cargando la página.

## Sistema de movimiento alrededor de la portada

- **Nada aparece de golpe.** Cada entrada, efecto hover y cambio de estado utiliza una transición suave. Define dos curvas de aceleración como variables y reutilízalas. Incluso la propia página aparece suavemente.
- **Las entradas son coreografía.** IntersectionObserver añade una clase `.in` y los hijos llegan en secuencia, con retrasos de 60 a 150 ms. Los estados inicial y final deben incluir la clase del contenedor, como `.card .part` y `.card.in .part`, para ganar en la cascada. Una regla posterior puede cancelar la animación de forma silenciosa. Cuando termine la entrada, RETIRA los retrasos escalonados. La regla que pone `transition-delay` en cero debe igualar o superar la especificidad de las reglas `nth-child`, porque `:nth-child` cuenta como una clase. De lo contrario, la limpieza nunca se aplica y los efectos hover de los últimos elementos siguen retrasados. Compruébalo pasando el cursor por los elementos segundo y tercero después de terminar la entrada.
- **Nunca coloques un estilo dinámico en el mismo elemento que tiene una animación de entrada con `forwards`.** El valor final de la animación ganará para siempre. Coloca la entrada en el padre y el estilo dinámico en un hijo.
- **Un elemento vivo por sección**, a un nivel muy sutil después de su entrada: un ciclo lento o resplandor de por lo menos cuatro segundos. Usa retrasos negativos, como `-1.2s`, para que las animaciones aparezcan a mitad del ciclo desde el primer dibujo. Pausa los ciclos fuera de pantalla limitando las reglas a una clase controlada por IntersectionObserver. Detén todo en pestañas ocultas mediante una clase en `body`. `animation-play-state` no se hereda, por lo que definirlo en un contenedor no llega a hijos ni pseudo-elementos. El patrón seguro es `body.paused *, body.paused *::before, body.paused *::after { animation-play-state: paused !important }`, activado con `visibilitychange`.
- **Un momento interactivo diseñado por sitio.** Debe tener intención, no ser solo decorativo. La forma comprobada se explica en la siguiente sección.
- **Anima únicamente `transform` y `opacity`.** Para resplandores, coloca la sombra completa en un pseudo-elemento y anima su opacidad.
- **El texto enmascarado necesita espacio para las colas de las letras.** Cualquier revelado con `overflow: hidden` necesita relleno basado en `em` y márgenes negativos equivalentes para no cortar g, y o p.
- **Nunca reemplaces `el.style.transition` desde JavaScript.** Activa una clase que declare la transición combinada completa.

## El único momento interactivo (forma comprobada)

Incluye uno por sitio, alineado con el tema y realizado a mitad del recorrido. La forma que ha funcionado repetidamente es una acción que refleja la historia del producto: mantener presionado para dejar que un aroma se asiente o para tirar de un hilo y cerrar una costura. El visitante no solo lee la idea central de la marca, sino que la ejecuta.

Detalles que hacen que se sienta diseñado y no como un truco:

- El progreso aumenta mientras el visitante mantiene presionado.
- Si suelta antes, el progreso regresa suavemente y nunca salta a cero.
- Al completarlo, el contenido de la sección se ilumina en secuencia. La acción del visitante produce una recompensa real.
- Con movimiento reducido se muestra de inmediato el estado final y no se requiere mantener presionado.

Mantener presionado es un ejemplo, no una ley. Cualquier interacción funciona si permite ejecutar la idea central de la marca.

## Desbordamiento y movimiento reducido

- Usa `overflow-x: clip` tanto en `html` como en `body`, declarando antes `hidden` como respaldo. `hidden` por sí solo todavía permite que el código desplace la página horizontalmente y un enlace interno puede dejarla fuera de posición.
- Respeta COMPLETAMENTE el movimiento reducido: detén animaciones y transiciones en elementos y en `::before` y `::after`; elimina todos los `transition-delay`; muestra cada elemento coreografiado en su estado final; y vuelve a aplicar las transformaciones de posición en cada punto de quiebre. Una regla general `transform: none !important` puede lanzar fuera de pantalla un elemento móvil cuya ubicación depende de una transformación. No cargues el video, porque movimiento reducido es una de las cinco condiciones de portada estática.
- Respeta el movimiento reducido EN VIVO y en AMBAS direcciones. Escucha el evento `change` de la consulta. Al activarse, fija cada elemento controlado por desplazamiento en su estado final y detén los procesos de JavaScript: completa líneas, lleva contadores a su valor y termina interacciones mantenidas. Al desactivarse, vuelve a preparar el video con la misma función de las cinco condiciones, para reiniciar cachés y recalcular textos. Revierte todo lo aplicado por `pinToFinalStates`: elimina clases o estilos en línea de líneas, contadores e interacciones para devolverles el control al desplazamiento. Reactivar la portada dejando el resto del sitio fijado es una solución incompleta.

```js
matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', e => {
  if (e.matches) pinToFinalStates();   // líneas completas, contadores terminados, interacciones listas
  else applyHeroMode();                // regresa el movimiento: reactiva todo y elimina estados fijos
});
```

## Dirección de diseño (qué hace que se vea costoso)

El nivel de ingeniería evita fallas. Estas reglas evitan que el resultado parezca generado automáticamente:

- **Comprométete con UNA dirección nacida del mundo del producto** y deja que gobierne paleta, tipografía, movimiento e imágenes. La página y el video deben sentirse como un solo lugar.
- **Inventa un elemento característico** exclusivo de este sitio y concentra ahí el atrevimiento. Todo lo demás se mantiene tranquilo para que destaque. Después comprueba su fuerza: si al eliminarlo la página casi no cambia, no es realmente característico. Invierte el impacto en algo cuya ausencia se note.
- **Dos secciones contiguas nunca comparten el mismo esqueleto.** Si ambas empiezan con etiqueta, título e introducción sobre la misma cuadrícula, cambia una. El visitante no debe sentir la misma plantilla repetida dos veces.
- **Evita las apariencias que anuncian "esto lo hizo una IA"**, salvo que el usuario pida una de forma explícita: fondo crema con tipografía serif y acento terracota; fondo casi negro con verde ácido; fondo casi negro con ámbar cálido y serif de alto contraste, que suele convertirse en el siguiente recurso automático cuando se pide algo oscuro, elegante o cinematográfico; y brutalismo con bordes muy delgados. Hay una excepción: se prohíben como soluciones automáticas, no como mundos auténticos de una marca. Si una de ellas corresponde de verdad al tema, por ejemplo un taller de cerámica que vive entre crema y terracota, manda el mundo del producto. Gánatelo tomando los colores del video, inventando el elemento característico y evitando el diseño genérico de plantilla. Explica esta decisión al usuario.
- **El acento aparece pocas veces:** llamada a la acción, estados de foco y uno o dos énfasis. Si aparece en todas partes, deja de ser un acento.
- **El fondo nunca es `#000` ni `#fff` puros.** Tiñe el color hacia la gradación del video.
- **Convierte la página en un solo ambiente.** Coloca una capa de fondo fija detrás de todo, como un movimiento lento, grano o resplandor del mundo del video, con ciclos de 60 segundos o más. Desplazarse debe sentirse como atravesar un lugar y no como pasar por bloques apilados.

## Nivel mínimo de calidad (completo, siempre)

- Limita las fuentes a los pesos utilizados y añade `preconnect`. Usa una tipografía de títulos con personalidad, otra tranquila para el cuerpo y una monoespaciada para etiquetas pequeñas. Nunca uses Inter o Roboto como tipografía de títulos.
- Define el ancho de los bloques de texto en unidades `ch` directamente sobre el elemento de texto, nunca en un contenedor. Una unidad `ch` se calcula con la fuente heredada por el elemento, no con la tipografía de título dentro de él. Por eso un límite `ch` en el contenedor puede medirse con la fuente equivocada. Para los contenedores usa `px` o `min()`. En un proyecto real, limitar el bloque final con los `ch` de la fuente del cuerpo partió el título en tres líneas.
- Calcula el contraste real sobre el fondo. No lo adivines. Exige 4.5:1 para texto normal y 3:1 para texto grande y bordes de interfaz. Los colores muy finos suelen fallar en bordes interactivos, así que usa un valor más fuerte para ellos.
- Utiliza regiones semánticas: `<nav>`, `<main id="main" tabindex="-1">`, `<footer>`, un enlace de salto a `#main`, jerarquía real de encabezados y `aria-hidden="true"` en elementos decorativos.
- El video es decorativo. Usa `aria-hidden="true"`, no añadas el atributo `controls` y mantenlo fuera del orden del teclado mediante `tabindex="-1"` o `inert` en la capa decorativa. Los usuarios de teclado y lector de pantalla deben llegar a los textos y al contenido, no al video.
- Diseña `:focus-visible` con el color de acento. En `(pointer: coarse)`, los objetivos táctiles deben medir por lo menos 44 píxeles sin alterar la distribución: `@media (pointer:coarse){ .btn { min-height:44px; display:inline-flex; align-items:center; justify-content:center } }`. Nunca cambies el tipo de visualización sin volver a declarar la alineación. Un `display:inline-flex` sin más puede alinear etiquetas a la izquierda y reducir filas completas al ancho de su texto.
- Incluye un `<title>` real, descripción meta, `theme-color` y favicon SVG en línea con el símbolo de la marca.
- `og:image` y `og:url` necesitan URLs absolutas que no existen hasta publicar. Deja un comentario claro `<!-- PASO DE DESPLIEGUE -->` y actualízalas con la URL final durante el despliegue, según `despliegue.md`.
- Las decoraciones nunca chocan con el contenido. Reserva espacio para los elementos con posición absoluta y ocúltalos en pantallas bajas mediante una consulta `max-height`.
- Alinea las filas de texto por la línea base con `align-items: baseline`, no por el centro de sus cajas.

## Lista de comprobación propia (ejecutar antes de mostrar el sitio)

Audita de forma adversarial. Comprueba, no supongas:

1. Captura el sitio en tamaño de escritorio y teléfono. Revisa al menos `1280x800`, `1440x900`, `375x812` y `375x667`.
2. Prueba todos los botones y enlaces. Envía el formulario y confirma su estado de respuesta.
3. Recorre la portada al principio, en medio y al final. Después hazlo rápidamente. Busca interrupciones, especialmente en Chrome.
4. Ejecuta la prueba del mapa con pasos de 120, 240 y 360 píxeles. Cada texto debe leerse durante 5 o 6 movimientos normales y ninguno puede saltarse con 360 píxeles.
5. Ejecuta la auditoría de legibilidad del peor fotograma. Cada banda debe conservar un contraste mínimo de 3.5:1 en el peor píxel bajo el texto y con la veladura aplicada.
6. Comprueba que todas las entradas se reproducen. La cascada puede cancelarlas silenciosamente.
7. Intenta desplazar la página hacia los lados mediante enlaces internos, decoraciones anchas y ventanas estrechas.
8. Prueba con movimiento reducido: estados finales visibles y ninguna solicitud de video. Actívalo también mientras la página está abierta. Todos los elementos controlados por desplazamiento deben pasar a su estado final y los procesos de JavaScript deben detenerse.
9. Carga el sitio con el archivo de video ausente. La página debe seguir completa sobre la imagen previa.
10. Revisa la consola en tamaños de computadora y teléfono. Debe haber cero errores.
11. Comprueba las colas de letras g, y y p en todos los textos recortados o enmascarados al 100 por ciento de zoom.
12. **Revisión con ojos nuevos, al final.** Deja a un lado la lista y observa la página como una persona que entra por primera vez, sin contexto. ¿Cada elemento tiene un lugar o alguno flota sin explicación? ¿Hay elementos paralelos tratados de forma desigual, como un paso sin imagen o una tarjeta distinta a sus hermanas? ¿El sitio se siente profesional y hecho para esta marca o alguna parte parece relleno? Corrige lo que detectes antes de que lo vea el usuario. Es una actividad distinta de la auditoría y encuentra cosas que la lista no puede prever.

**Cuando exista un navegador controlable, ejecuta pruebas reales y no aproximaciones.** La ruta de Chrome headless de `solucion-de-problemas.md` da control completo de un navegador real. Cuatro comprobaciones solo pueden realizarse de forma auténtica así: la emulación táctil activa `(pointer: coarse)` y permite probar tres de las cinco condiciones de portada estática; la emulación de medios cambia `prefers-reduced-motion` en vivo y comprueba el requisito bidireccional del paso 8; `Network.setBlockedURLs` bloquea la URL del video para probar el sitio sin cambiar el nombre del archivo; y una presión y liberación reales del mouse, con una pausa entre ambas, comprueban la interacción de mantener presionado tal como la realiza un visitante.

Si el entorno permite revisores independientes, como un segundo agente u otra persona con ojos nuevos, pídeles revisar también el resultado. La lista demuestra lo que pensaste comprobar. Un revisor adversarial encuentra lo que no se te ocurrió.

Informa qué encontraste y qué corregiste. La última revisión corresponde al usuario, pero no debe ser quien encuentre tus errores.
